"""Main Glue job orchestration script for WealthBridge Financial Data Platform."""
from __future__ import annotations

import sys
import time
from typing import Any, Dict, List, Tuple

from pyspark.sql import SparkSession

from glue.config import load_config
from glue.dq_engine import apply_rules, calculate_dq_score
from glue.iceberg_writer import write_bad, write_good
from glue.logger import get_logger
from glue.metadata_writer import (
    record_ingestion_run_start,
    record_rule_failure_summary,
    record_source_file,
    update_ingestion_run_finish,
)
from glue.reader import read_entity_csv, resolve_batch_files
from glue.rule_loader import load_active_rules
from glue.summary_generator import build_summary
from glue.utils import new_run_id, read_job_args, tag_s3_object


def get_spark_session(app_name: str = "WealthBridgeIngestionJob") -> Any:
    """Creates or gets active SparkSession, returning None if Spark runtime is unavailable locally."""
    try:
        spark = (
            SparkSession.builder.appName(app_name)
            .master("local[*]")
            .getOrCreate()
        )
        spark.sparkContext.setLogLevel("WARN")
        return spark
    except Exception as err:
        print(f"[spark_init_info] Local PySpark session unavailable ({err}). Falling back to local engine.")
        return None


def run_pipeline(job_args: Dict[str, str], db_conn: Any = None) -> int:
    start_ts = time.time()
    batch_id = job_args.get("batch_id", "batch1")
    file_id = job_args.get("file_id", "1234")
    env = job_args.get("env", "dev")
    run_id = new_run_id(batch_id, file_id)

    logger = get_logger("glue_main", run_id=run_id, batch_id=batch_id, file_id=file_id)
    logger.info(f"Starting ingestion pipeline for batch_id={batch_id}, file_id={file_id}, env={env}", extra={"stage": "INIT"})

    cfg = load_config(env=env)
    logger.info(f"Loaded config for environment={cfg.environment}, region={cfg.aws.region}", extra={"stage": "CONFIG"})

    # Record run start in metadata store
    record_ingestion_run_start(db_conn, run_id, batch_id, file_id)

    spark = get_spark_session(cfg.glue.job_name)

    resolved_files = resolve_batch_files(batch_id, file_id, base_dir_or_bucket="sample_data")
    logger.info(f"Resolved files: {resolved_files}", extra={"stage": "RESOLVE_FILES"})

    entities = ["TRANSACTION", "POSITION"]
    entity_results: Dict[str, Any] = {}
    combined_failures: Dict[str, int] = {}
    all_bad_records: List[Dict[str, Any]] = []

    total_good_all = 0
    total_bad_all = 0
    total_records_all = 0

    for entity in entities:
        logger.info(f"Processing entity={entity}", extra={"stage": f"PROCESS_{entity}"})
        try:
            file_path = resolved_files.get(entity)
            if not file_path:
                logger.warning(f"No source file found for entity={entity}", extra={"stage": f"READ_{entity}"})
                entity_results[entity] = {"status": "MISSING", "good": 0, "bad": 0, "total": 0}
                continue

            rules = load_active_rules(conn=db_conn, entity_type=entity)
            logger.info(f"Loaded {len(rules)} active rules for entity={entity}", extra={"stage": f"RULES_{entity}"})

            df = read_entity_csv(spark, file_path)
            raw_count = df.count()
            logger.info(f"Read {raw_count} rows for entity={entity}", extra={"stage": f"READ_{entity}"})

            # Execute DQ Rule Engine
            good_recs, bad_recs, fail_counts = apply_rules(df, rules)
            g_cnt, b_cnt = len(good_recs), len(bad_recs)
            t_cnt = g_cnt + b_cnt

            total_good_all += g_cnt
            total_bad_all += b_cnt
            total_records_all += t_cnt

            # Accumulate bad records
            all_bad_records.extend(bad_recs)

            # Aggregate failure counts
            for r_id, cnt in fail_counts.items():
                combined_failures[r_id] = combined_failures.get(r_id, 0) + cnt

            # Context for writers
            file_name = file_path.split("/")[-1].split("\\")[-1]
            run_ctx = {
                "run_id": run_id,
                "batch_id": batch_id,
                "file_id": file_id,
                "source_file": file_name,
            }

            # Write to Iceberg curated storage
            write_good(spark, good_recs, entity, run_ctx, catalog_db=cfg.glue.iceberg_db)
            write_bad(spark, bad_recs, entity, run_ctx, catalog_db=cfg.glue.iceberg_db)

            # Record file metadata and failure summary
            record_source_file(
                db_conn, run_id, file_name, entity, file_path, batch_id, file_id, t_cnt, g_cnt, b_cnt, "PROCESSED"
            )
            record_rule_failure_summary(db_conn, run_id, batch_id, file_id, entity, fail_counts)

            # Tag S3 object as Completed
            tag_s3_object(cfg.s3.landing_bucket, file_name, "Completed", region_name=cfg.aws.region)

            entity_results[entity] = {"status": "SUCCESS", "good": g_cnt, "bad": b_cnt, "total": t_cnt}

        except Exception as err:
            logger.error(f"Error processing entity={entity}: {err}", extra={"stage": f"ERROR_{entity}"}, exc_info=True)
            entity_results[entity] = {"status": "FAILED", "error": str(err)}

    # Pipeline overall status determination
    statuses = [res["status"] for res in entity_results.values()]
    if all(s == "SUCCESS" for s in statuses):
        overall_status = "COMPLETED"
    elif any(s == "SUCCESS" for s in statuses):
        overall_status = "PARTIAL"
    else:
        overall_status = "FAILED"

    duration = round(time.time() - start_ts, 2)
    dq_score = calculate_dq_score(total_good_all, total_records_all)

    # Top failures for operational summary
    top_failures = sorted(
        [(r_id, cnt) for r_id, cnt in combined_failures.items() if cnt > 0],
        key=lambda x: x[1],
        reverse=True,
    )

    run_summary_ctx = {
        "run_id": run_id,
        "batch_id": batch_id,
        "file_id": file_id,
        "status": overall_status,
        "duration_seconds": duration,
    }
    stats_dict = {
        "total_records": total_records_all,
        "good_records": total_good_all,
        "bad_records": total_bad_all,
        "dq_score": dq_score,
    }

    summary_text = build_summary(run_summary_ctx, stats_dict, top_failures)
    logger.info(f"Generated Summary: {summary_text}", extra={"stage": "SUMMARY"})

    # Generate Dynamic HTML Dashboard Report with AI analysis & correction guide
    try:
        from glue.summary_generator import generate_html_report
        generate_html_report(run_summary_ctx, stats_dict, top_failures, all_bad_records, "ingestion_report.html")
    except Exception as err:
        logger.error(f"Failed to generate HTML report: {err}", extra={"stage": "REPORT_ERROR"})


    # Update metadata store with run completion
    update_ingestion_run_finish(
        db_conn,
        run_id=run_id,
        duration_seconds=duration,
        total_records=total_records_all,
        good_records=total_good_all,
        bad_records=total_bad_all,
        dq_score=dq_score,
        status=overall_status,
        summary=summary_text,
    )

    logger.info(f"Completed ingestion pipeline with status={overall_status}, dq_score={dq_score}%.", extra={"stage": "COMPLETE"})
    return 0 if overall_status in ("COMPLETED", "PARTIAL") else 1


def main() -> None:
    args = read_job_args()
    exit_code = run_pipeline(args)
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
