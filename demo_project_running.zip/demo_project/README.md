# WealthBridge Financial Data Platform

Enterprise financial data platform for processing near-real-time transaction and position batch files on AWS Glue and Apache Iceberg.

## Repository Layout
```
demo_project/
├── CONTINUATION_PLAN.md    # Master handoff plan
├── README.md               # Project overview and guide
├── requirements.txt        # Python dependencies
├── template.yaml           # AWS SAM infrastructure stack
├── .gitignore              # Environment / secret exclusions
├── config/                 # Base and env-specific YAML configs
├── sql/                    # PostgreSQL schema & rule seed scripts
├── glue/                   # Glue PySpark ETL application modules
│   ├── main.py             # Orchestration script
│   ├── config.py           # Typed config loader
│   ├── logger.py           # Structured JSON logger
│   ├── utils.py            # Utility functions (filename parser)
│   ├── reader.py           # Ingestion CSV reader
│   ├── rule_loader.py      # DQ rule loader
│   ├── validators.py       # Rule validators & type casting
│   ├── dq_engine.py        # DQ engine & record splitter
│   ├── iceberg_writer.py   # Iceberg S3 curated writer
│   ├── metadata_writer.py  # RDS PostgreSQL metadata writer
│   └── summary_generator.py# Operational summary generator
├── lambdas/                # AWS Lambda functions (Preprocessor & Notifier)
├── sample_data/            # Phase 3 sample CSV files & oracle generator
├── tests/                  # Pytest unit & cross-check test suite
└── docs/                   # Complete architecture & operation docs
```

## Quickstart

### Run Test Suite
```bash
python -m pytest -v
```

### Local Pipeline Execution
```bash
python -m glue.main --batch_id batch1 --file_id 1234 --env dev
```
