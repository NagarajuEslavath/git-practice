"""Notifier Lambda function: reads operational summary and outputs notifications."""
from __future__ import annotations

import json
from typing import Any, Dict


class NotificationSink:
    """Pluggable notification interface (CloudWatch log stub, expandable to SNS/Email/Slack)."""

    def send_notification(self, run_id: str, summary: str) -> bool:
        print(f"[NOTIFICATION_SINK] RunID: {run_id} | Summary: {summary}")
        return True


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """Lambda entry point for notification dispatch."""
    run_id = event.get("run_id", "UNKNOWN")
    summary = event.get("summary", "No summary provided.")

    sink = NotificationSink()
    sink.send_notification(run_id, summary)

    return {
        "statusCode": 200,
        "body": json.dumps({"status": "SUCCESS", "run_id": run_id}),
    }
