"""Preprocessor Lambda function: S3 event handling, manifest tracking, completeness check, and Glue trigger."""
from __future__ import annotations

import os
import urllib.parse
from typing import Any, Dict, Optional, Tuple

import boto3
from glue.utils import parse_filename

GLUE_JOB_NAME = os.getenv("GLUE_JOB_NAME", "wealthbridge-ingestion-job")
AWS_REGION = os.getenv("AWS_REGION", "ap-south-1")


def register_file_manifest(db_conn: Any, bucket: str, key: str, batch_id: str, file_id: str, entity_type: str) -> bool:
    """Inserts a row into file_manifest ON CONFLICT DO NOTHING."""
    if db_conn is None:
        return True
    try:
        with db_conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO file_manifest (s3_bucket, s3_key, batch_id, file_id, entity_type, status)
                VALUES (%s, %s, %s, %s, %s, 'REGISTERED')
                ON CONFLICT (s3_bucket, s3_key) DO NOTHING;
                """,
                (bucket, key, batch_id, file_id, entity_type),
            )
        db_conn.commit()
        return True
    except Exception as err:
        db_conn.rollback()
        print(f"[preprocessor_error] Failed to register manifest for s3://{bucket}/{key}: {err}")
        return False


def check_and_trigger_glue(db_conn: Any, batch_id: str, file_id: str, glue_client: Any = None) -> bool:
    """
    Checks if both TRANSACTION and POSITION files exist and are not processed.
    Transactionally marks them TRIGGERED and invokes Glue job.
    """
    if db_conn is not None:
        try:
            with db_conn.cursor() as cur:
                # Check for both entity types
                cur.execute(
                    """
                    SELECT entity_type, status FROM file_manifest
                    WHERE batch_id = %s AND file_id = %s AND status IN ('REGISTERED', 'TRIGGERED');
                    """,
                    (batch_id, file_id),
                )
                rows = cur.fetchall()
                entities_present = {r[0] for r in rows if r[1] == "REGISTERED"}

                if "TRANSACTION" in entities_present and "POSITION" in entities_present:
                    # Update status to TRIGGERED
                    cur.execute(
                        """
                        UPDATE file_manifest
                        SET status = 'TRIGGERED'
                        WHERE batch_id = %s AND file_id = %s AND status = 'REGISTERED';
                        """,
                        (batch_id, file_id),
                    )
                    db_conn.commit()
                else:
                    return False
        except Exception as err:
            db_conn.rollback()
            print(f"[preprocessor_error] Completeness check failed for ({batch_id}, {file_id}): {err}")
            return False

    # Trigger Glue Job Run
    if glue_client is None:
        glue_client = boto3.client("glue", region_name=AWS_REGION)

    try:
        response = glue_client.start_job_run(
            JobName=GLUE_JOB_NAME,
            Arguments={
                "--batch_id": batch_id,
                "--file_id": file_id,
            },
        )
        print(f"[preprocessor_success] Triggered Glue Job {GLUE_JOB_NAME} for batch_id={batch_id}, file_id={file_id}. RunId={response.get('JobRunId')}")
        return True
    except Exception as err:
        print(f"[preprocessor_error] Glue start_job_run failed: {err}")
        return False


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """S3 ObjectCreated Event Handler."""
    records = event.get("Records", [])
    processed_files = []

    for rec in records:
        bucket = rec["s3"]["bucket"]["name"]
        key = urllib.parse.unquote_plus(rec["s3"]["object"]["key"])

        parsed = parse_filename(key)
        if not parsed:
            print(f"[preprocessor_warning] Rejecting malformed key s3://{bucket}/{key}")
            # Tag object as Rejected
            try:
                s3 = boto3.client("s3", region_name=AWS_REGION)
                s3.put_object_tagging(
                    Bucket=bucket, Key=key, Tagging={"TagSet": [{"Key": "ProcessStatus", "Value": "Rejected"}]}
                )
            except Exception as e:
                print(f"[s3_tag_error] {e}")
            continue

        register_file_manifest(None, bucket, key, parsed.batch_id, parsed.file_id, parsed.entity_type)
        check_and_trigger_glue(None, parsed.batch_id, parsed.file_id)
        processed_files.append(key)

    return {
        "statusCode": 200,
        "body": f"Successfully processed {len(processed_files)} S3 records.",
    }
