-- =============================================================================
-- 99_drop_all.sql
-- DEV/TEST teardown only. Drops all metadata objects in dependency order.
-- Do NOT run in production.
-- =============================================================================

DROP TABLE IF EXISTS dq_rule_failure_summary CASCADE;
DROP TABLE IF EXISTS source_file             CASCADE;
DROP TABLE IF EXISTS file_manifest           CASCADE;
DROP TABLE IF EXISTS dq_rule_registry        CASCADE;
DROP TABLE IF EXISTS ingestion_run           CASCADE;

DROP FUNCTION IF EXISTS set_updated_at() CASCADE;
