-- =============================================================================
-- 03_create_source_file.sql
-- Table  : source_file
-- Grain  : ONE row per physical file processed within a run
--          (typically 2 rows per run: one TRANSACTION, one POSITION).
-- Run order: after 01_create_ingestion_run.sql. Idempotent.
-- =============================================================================

CREATE TABLE IF NOT EXISTS source_file (
    source_file_id      BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    run_id              VARCHAR(100)  NOT NULL REFERENCES ingestion_run(run_id) ON DELETE CASCADE,
    file_name           VARCHAR(512)  NOT NULL,
    file_type           VARCHAR(20)   NOT NULL CHECK (file_type IN ('TRANSACTION','POSITION')),
    s3_path             VARCHAR(1024) NOT NULL,
    batch_id            VARCHAR(50)   NOT NULL,
    file_id             VARCHAR(50)   NOT NULL,
    record_count        BIGINT        NOT NULL DEFAULT 0,
    good_count          BIGINT        NOT NULL DEFAULT 0,
    bad_count           BIGINT        NOT NULL DEFAULT 0,
    processing_status   VARCHAR(20)   NOT NULL DEFAULT 'PROCESSED'
                            CHECK (processing_status IN ('PROCESSED','FAILED')),
    processed_timestamp TIMESTAMPTZ   NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_source_file_run        ON source_file (run_id);
CREATE INDEX IF NOT EXISTS idx_source_file_batch_file ON source_file (batch_id, file_id);
CREATE INDEX IF NOT EXISTS idx_source_file_type       ON source_file (file_type);

COMMENT ON TABLE  source_file             IS 'Per-file processing outcome inside a run.';
COMMENT ON COLUMN source_file.file_type   IS 'TRANSACTION or POSITION, derived from the filename.';
COMMENT ON COLUMN source_file.s3_path     IS 'Full s3://bucket/key path of the processed object.';
