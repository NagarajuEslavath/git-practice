-- =============================================================================
-- 00_common.sql
-- Shared database objects used across the metadata schema.
-- Database : WealthBridgeMetadataDatabase (Amazon RDS PostgreSQL)
-- Run order: FIRST. Idempotent (safe to re-run).
-- =============================================================================

-- Automatically maintains an `updated_at` column on UPDATE.
-- Attached to tables that track a mutable lifecycle (e.g. file_manifest).
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at := now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION set_updated_at() IS
    'Trigger function: stamps NEW.updated_at with the current timestamp on every UPDATE.';
