-- =============================================================================
-- 05_create_dq_rule_failure_summary.sql
-- Table  : dq_rule_failure_summary
-- Grain  : ONE row per (run_id, rule_id, entity_type) with the count of records
--          that failed that rule. Feeds the "top failed rules" section of the
--          Python operational summary.
-- Run order: after 01_create_ingestion_run.sql and 04_create_dq_rule_registry.sql.
-- Idempotent.
-- =============================================================================

CREATE TABLE IF NOT EXISTS dq_rule_failure_summary (
    failure_summary_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    run_id             VARCHAR(100) NOT NULL REFERENCES ingestion_run(run_id)   ON DELETE CASCADE,
    batch_id           VARCHAR(50)  NOT NULL,
    file_id            VARCHAR(50)  NOT NULL,
    rule_id            BIGINT       NOT NULL REFERENCES dq_rule_registry(rule_id),
    entity_type        VARCHAR(20)  NOT NULL CHECK (entity_type IN ('TRANSACTION','POSITION')),
    failure_count      BIGINT       NOT NULL DEFAULT 0,
    created_at         TIMESTAMPTZ  NOT NULL DEFAULT now(),

    CONSTRAINT uq_failure_summary UNIQUE (run_id, rule_id, entity_type)
);

CREATE INDEX IF NOT EXISTS idx_failure_summary_run  ON dq_rule_failure_summary (run_id);
CREATE INDEX IF NOT EXISTS idx_failure_summary_rule ON dq_rule_failure_summary (rule_id);

COMMENT ON TABLE  dq_rule_failure_summary IS 'Per-run, per-rule failure counts; drives the top-failed-rules narrative.';
