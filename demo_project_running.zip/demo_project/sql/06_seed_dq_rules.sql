-- =============================================================================
-- 06_seed_dq_rules.sql
-- Seeds the dq_rule_registry with the confirmed TRANSACTION and POSITION rules.
-- Idempotent: ON CONFLICT (rule_code) DO NOTHING, so re-running is safe.
--
-- Canonical column names (these become the CSV headers in Phase 3):
--   transactions: transaction_id, account_id, transaction_type, trade_date,
--                 settlement_date, quantity, price, amount, currency
--   positions   : position_id, account_id, position_date, quantity_held,
--                 market_value, currency
--
-- Currency allow-list is a starter ISO set; extend it here or migrate to a
-- reference table without touching Glue code.
-- =============================================================================

-- ---------------------------------------------------------------------------
-- TRANSACTION RULES
-- ---------------------------------------------------------------------------
INSERT INTO dq_rule_registry
    (rule_code, entity_type, rule_name, rule_type, target_column, rule_expression, expected_data_type, severity)
VALUES
    ('TXN_TRANSACTION_ID_NOT_NULL', 'TRANSACTION', 'Transaction ID must not be null',
        'NOT_NULL',       'transaction_id',   NULL,                                          'STRING',  'CRITICAL'),
    ('TXN_TRANSACTION_ID_UNIQUE',   'TRANSACTION', 'Transaction ID must be unique within batch',
        'UNIQUE',         'transaction_id',   NULL,                                          'STRING',  'CRITICAL'),
    ('TXN_ACCOUNT_ID_PREFIX',       'TRANSACTION', 'Account ID must start with CV',
        'EXPRESSION',     'account_id',       'account_id LIKE ''CV%''',                     'STRING',  'CRITICAL'),
    ('TXN_TYPE_ALLOWED',            'TRANSACTION', 'Transaction type must be an approved value',
        'ALLOWED_VALUES', 'transaction_type', 'BUY,SELL,DIVIDEND,TRANSFER',                  'STRING',  'CRITICAL'),
    ('TXN_TRADE_LE_SETTLEMENT',     'TRANSACTION', 'Trade date must be on or before settlement date',
        'EXPRESSION',     'trade_date',       'trade_date <= settlement_date',               'DATE',    'CRITICAL'),
    ('TXN_QUANTITY_POSITIVE',       'TRANSACTION', 'Quantity must be greater than zero',
        'EXPRESSION',     'quantity',         'quantity > 0',                                'DECIMAL', 'CRITICAL'),
    ('TXN_PRICE_POSITIVE',          'TRANSACTION', 'Price must be greater than zero',
        'EXPRESSION',     'price',            'price > 0',                                   'DECIMAL', 'CRITICAL'),
    ('TXN_AMOUNT_POSITIVE',         'TRANSACTION', 'Amount must be greater than zero',
        'EXPRESSION',     'amount',           'amount > 0',                                  'DECIMAL', 'CRITICAL'),
    ('TXN_CURRENCY_ALLOWED',        'TRANSACTION', 'Currency must be a valid ISO code',
        'ALLOWED_VALUES', 'currency',         'USD,EUR,GBP,INR,JPY,AUD,CAD,CHF,SGD,HKD',     'STRING',  'CRITICAL')
ON CONFLICT (rule_code) DO NOTHING;

-- ---------------------------------------------------------------------------
-- POSITION RULES
-- ---------------------------------------------------------------------------
INSERT INTO dq_rule_registry
    (rule_code, entity_type, rule_name, rule_type, target_column, rule_expression, expected_data_type, severity)
VALUES
    ('POS_POSITION_ID_NOT_NULL',    'POSITION', 'Position ID must not be null',
        'NOT_NULL',       'position_id',    NULL,                                            'STRING',  'CRITICAL'),
    ('POS_POSITION_ID_UNIQUE',      'POSITION', 'Position ID must be unique within batch',
        'UNIQUE',         'position_id',    NULL,                                            'STRING',  'CRITICAL'),
    ('POS_ACCOUNT_ID_PREFIX',       'POSITION', 'Account ID must start with CV',
        'EXPRESSION',     'account_id',     'account_id LIKE ''CV%''',                       'STRING',  'CRITICAL'),
    ('POS_DATE_NOT_FUTURE',         'POSITION', 'Position date cannot be in the future',
        'EXPRESSION',     'position_date',  'position_date <= current_date()',               'DATE',    'CRITICAL'),
    ('POS_QUANTITY_NONNEG',         'POSITION', 'Quantity held cannot be negative',
        'EXPRESSION',     'quantity_held',  'quantity_held >= 0',                            'DECIMAL', 'CRITICAL'),
    ('POS_MARKET_VALUE_NONNEG',     'POSITION', 'Market value cannot be negative',
        'EXPRESSION',     'market_value',   'market_value >= 0',                             'DECIMAL', 'CRITICAL'),
    ('POS_CURRENCY_ALLOWED',        'POSITION', 'Currency must be a valid ISO code',
        'ALLOWED_VALUES', 'currency',       'USD,EUR,GBP,INR,JPY,AUD,CAD,CHF,SGD,HKD',       'STRING',  'CRITICAL')
ON CONFLICT (rule_code) DO NOTHING;
