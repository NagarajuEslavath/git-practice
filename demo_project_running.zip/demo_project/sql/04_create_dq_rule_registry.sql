-- =============================================================================
-- 04_create_dq_rule_registry.sql
-- Table  : dq_rule_registry
-- Purpose: Configuration-driven data-quality rules. The Glue rule engine loads
--          ACTIVE rules at runtime and executes them dynamically. Adding a new
--          rule is an INSERT here -- never a code change.
--
-- rule_type semantics (how the engine interprets each row):
--   NOT_NULL        -> engine builds  "<target_column> IS NOT NULL"
--   UNIQUE          -> engine flags rows whose <target_column> is duplicated
--                      WITHIN the current batch (within-batch uniqueness)
--   ALLOWED_VALUES  -> rule_expression holds a comma-separated allow-list;
--                      engine builds  "<target_column> IN (...)"
--   EXPRESSION      -> rule_expression is a full Spark SQL boolean expression
--                      that must evaluate TRUE for a GOOD record
--
-- expected_data_type: the type every column referenced by this rule is cast to
--   before evaluation (the CSV is header-inferred, then cast on demand).
--   Constraint: an EXPRESSION rule's columns must all share this one type, so
--   split any mixed-type comparison into separate rules.
--
-- severity: CRITICAL failures classify a record as BAD; WARNING failures are
--   counted and logged but the record remains GOOD.
--
-- Run order: after 01_create_ingestion_run.sql. Idempotent.
-- =============================================================================

CREATE TABLE IF NOT EXISTS dq_rule_registry (
    rule_id            BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    rule_code          VARCHAR(80)  NOT NULL UNIQUE,      -- stable human-readable code
    entity_type        VARCHAR(20)  NOT NULL CHECK (entity_type IN ('TRANSACTION','POSITION')),
    rule_name          VARCHAR(200) NOT NULL,
    rule_type          VARCHAR(20)  NOT NULL
                           CHECK (rule_type IN ('NOT_NULL','UNIQUE','ALLOWED_VALUES','EXPRESSION')),
    target_column      VARCHAR(100) NOT NULL,
    rule_expression    TEXT,                              -- NULL for NOT_NULL/UNIQUE
    expected_data_type VARCHAR(20)  NOT NULL DEFAULT 'STRING'
                           CHECK (expected_data_type IN
                               ('STRING','INT','BIGINT','DECIMAL','DATE','TIMESTAMP','BOOLEAN')),
    severity           VARCHAR(20)  NOT NULL DEFAULT 'CRITICAL'
                           CHECK (severity IN ('CRITICAL','WARNING')),
    active_flag        BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at         TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_dq_rule_entity_active ON dq_rule_registry (entity_type, active_flag);

COMMENT ON TABLE  dq_rule_registry                    IS 'Configuration-driven DQ rules loaded dynamically by the Glue rule engine.';
COMMENT ON COLUMN dq_rule_registry.rule_type          IS 'NOT_NULL | UNIQUE | ALLOWED_VALUES | EXPRESSION.';
COMMENT ON COLUMN dq_rule_registry.rule_expression    IS 'Spark SQL boolean expression (EXPRESSION) or comma-separated allow-list (ALLOWED_VALUES).';
COMMENT ON COLUMN dq_rule_registry.expected_data_type IS 'Type all referenced columns are cast to before evaluation.';
COMMENT ON COLUMN dq_rule_registry.severity           IS 'CRITICAL -> record becomes BAD; WARNING -> counted only.';
