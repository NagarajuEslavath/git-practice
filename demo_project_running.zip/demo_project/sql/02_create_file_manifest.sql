-- =============================================================================
-- 02_create_file_manifest.sql
-- Table  : file_manifest
-- Purpose: The anti-reprocess control plane, owned by the preprocessor Lambda.
--          Every object that lands in the S3 landing bucket is registered here
--          exactly once. Completeness (both entity files present for a file_id)
--          drives the single push trigger to Glue.
-- Grain  : ONE row per physical S3 object.
-- Run order: after 01_create_ingestion_run.sql. Idempotent.
-- =============================================================================

CREATE TABLE IF NOT EXISTS file_manifest (
    manifest_id       BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    s3_bucket         VARCHAR(255)  NOT NULL,
    s3_key            VARCHAR(1024) NOT NULL,
    file_name         VARCHAR(512)  NOT NULL,
    batch_id          VARCHAR(50),                        -- NULL if filename is malformed
    file_id           VARCHAR(50),                        -- NULL if filename is malformed
    entity_type       VARCHAR(20)
                          CHECK (entity_type IN ('TRANSACTION','POSITION')),
    record_count      BIGINT,                             -- filled after processing
    processing_status VARCHAR(20)   NOT NULL DEFAULT 'PENDING'
                          CHECK (processing_status IN
                              ('PENDING','TRIGGERED','COMPLETED','FAILED','REJECTED','SKIPPED_DUPLICATE')),
    run_id            VARCHAR(100)  REFERENCES ingestion_run(run_id) ON DELETE SET NULL,
    reject_reason     VARCHAR(512),
    arrival_timestamp TIMESTAMPTZ   NOT NULL DEFAULT now(),
    updated_at        TIMESTAMPTZ   NOT NULL DEFAULT now(),

    -- Dedupe key: a given S3 object is registered once. The Lambda uses
    -- INSERT ... ON CONFLICT (s3_bucket, s3_key) DO NOTHING to stay idempotent
    -- against duplicate S3 event deliveries.
    CONSTRAINT uq_file_manifest_object UNIQUE (s3_bucket, s3_key)
);

CREATE INDEX IF NOT EXISTS idx_file_manifest_batch_file ON file_manifest (batch_id, file_id);
CREATE INDEX IF NOT EXISTS idx_file_manifest_status     ON file_manifest (processing_status);
CREATE INDEX IF NOT EXISTS idx_file_manifest_run        ON file_manifest (run_id);

DROP TRIGGER IF EXISTS trg_file_manifest_updated_at ON file_manifest;
CREATE TRIGGER trg_file_manifest_updated_at
    BEFORE UPDATE ON file_manifest
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

COMMENT ON TABLE  file_manifest                    IS 'One row per S3 object; the source of truth for anti-reprocessing and batch completeness.';
COMMENT ON COLUMN file_manifest.processing_status  IS 'PENDING (registered) -> TRIGGERED (Glue started) -> COMPLETED/FAILED. REJECTED = bad filename. SKIPPED_DUPLICATE = already processed.';
COMMENT ON COLUMN file_manifest.entity_type        IS 'Derived from filename token 3 via fuzzy match (handles the transcation misspelling and trailing digits).';
