-- =============================================================================
-- 01_create_ingestion_run.sql
-- Table  : ingestion_run
-- Grain  : ONE row per Glue job run.
--          A run processes exactly one file_id == one TRANSACTION file
--          plus one POSITION file (the confirmed processing unit).
-- Notes  : dq_score is a single COMBINED score across both entities, expressed
--          as a percentage (0.00 - 100.00). No UNIQUE(batch_id,file_id) here on
--          purpose: a FAILED run must be re-runnable. Duplicate *processing*
--          is prevented by file_manifest, not by this table.
-- Run order: after 00_common.sql. Idempotent.
-- =============================================================================

CREATE TABLE IF NOT EXISTS ingestion_run (
    run_id            VARCHAR(100) PRIMARY KEY,          -- Glue jobRunId or generated UUID
    batch_id          VARCHAR(50)  NOT NULL,             -- e.g. 'batch1'
    file_id           VARCHAR(50)  NOT NULL,             -- e.g. '1234'
    start_time        TIMESTAMPTZ  NOT NULL DEFAULT now(),
    end_time          TIMESTAMPTZ,
    duration_seconds  NUMERIC(12,2),
    total_records     BIGINT       NOT NULL DEFAULT 0,
    good_records      BIGINT       NOT NULL DEFAULT 0,
    bad_records       BIGINT       NOT NULL DEFAULT 0,
    dq_score          NUMERIC(5,2),                      -- combined %, 0.00 - 100.00
    status            VARCHAR(20)  NOT NULL DEFAULT 'RUNNING'
                          CHECK (status IN ('RUNNING','COMPLETED','FAILED','PARTIAL')),
    summary           TEXT,                              -- deterministic Python operational summary
    created_at        TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_ingestion_run_batch_file ON ingestion_run (batch_id, file_id);
CREATE INDEX IF NOT EXISTS idx_ingestion_run_status     ON ingestion_run (status);
CREATE INDEX IF NOT EXISTS idx_ingestion_run_start_time ON ingestion_run (start_time DESC);

COMMENT ON TABLE  ingestion_run             IS 'One row per Glue run; a run processes one file_id (one transaction + one position file).';
COMMENT ON COLUMN ingestion_run.run_id      IS 'Primary key. Glue jobRunId or a UUID generated at run start.';
COMMENT ON COLUMN ingestion_run.dq_score    IS 'Combined data-quality score across both entities, as a percentage.';
COMMENT ON COLUMN ingestion_run.status      IS 'RUNNING | COMPLETED | FAILED | PARTIAL (one entity succeeded, the other failed).';
COMMENT ON COLUMN ingestion_run.summary     IS 'Business-friendly operational summary generated in Python (no Bedrock).';
