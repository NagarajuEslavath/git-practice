"""Iceberg writer module for curated good and bad data tables."""
from __future__ import annotations

import datetime as dt
from pathlib import Path
from typing import Any, Dict, List, Optional


def attach_metadata_columns(
    records: List[Dict[str, Any]],
    run_ctx: Dict[str, Any],
    dq_status: str,
) -> List[Dict[str, Any]]:
    """
    Appends the 7 required metadata columns to each record:
    ingestion_run_id, batch_id, source_file, dq_status, failed_rule_id,
    failure_reason, processed_timestamp.
    """
    now_iso = dt.datetime.now(dt.timezone.utc).isoformat()
    enriched: List[Dict[str, Any]] = []

    for r in records:
        rec = dict(r)
        rec["ingestion_run_id"] = run_ctx.get("run_id")
        rec["batch_id"] = run_ctx.get("batch_id")
        rec["source_file"] = run_ctx.get("source_file")
        rec["dq_status"] = rec.get("dq_status", dq_status)

        if dq_status.upper() == "GOOD":
            rec["failed_rule_id"] = None
            rec["failure_reason"] = None
        else:
            rec["failed_rule_id"] = rec.get("failed_rule_id")
            rec["failure_reason"] = rec.get("failure_reason")

        rec["processed_timestamp"] = now_iso
        enriched.append(rec)

    return enriched


def write_to_iceberg(
    spark: Any,
    records: List[Dict[str, Any]],
    table_name: str,
    catalog_db: str = "iceberg_db",
    warehouse_path: str = "curated_warehouse",
) -> int:
    """
    Writes enriched records into Iceberg table catalog_db.table_name, partitioned by batch_id.
    Falls back to local file/json warehouse persistence if PySpark session / Glue catalog is absent locally.
    """
    if not records:
        return 0

    full_table_name = f"{catalog_db}.{table_name}"

    if spark is not None and hasattr(spark, "createDataFrame"):
        try:
            df = spark.createDataFrame(records)
            df.write.format("iceberg").mode("append").partitionBy("batch_id").saveAsTable(full_table_name)
            return len(records)
        except Exception as err:
            print(f"[iceberg_writer_warning] Could not write to Iceberg catalog table {full_table_name}: {err}. Writing to local warehouse.")

    # Local warehouse fallback for local verification
    out_dir = Path(warehouse_path) / catalog_db / table_name
    out_dir.mkdir(parents=True, exist_ok=True)
    batch_id = records[0].get("batch_id", "default")
    file_path = out_dir / f"part_{batch_id}.json"

    import json
    with open(file_path, "a", encoding="utf-8") as f:
        for rec in records:
            f.write(json.dumps(rec) + "\n")

    return len(records)


def write_good(
    spark: Any,
    records: List[Dict[str, Any]],
    entity_type: str,
    run_ctx: Dict[str, Any],
    catalog_db: str = "iceberg_db",
) -> int:
    """Writes good records to curated good table."""
    table_name = f"{entity_type.lower()}_good"
    enriched = attach_metadata_columns(records, run_ctx, dq_status="GOOD")
    return write_to_iceberg(spark, enriched, table_name, catalog_db=catalog_db)


def write_bad(
    spark: Any,
    records: List[Dict[str, Any]],
    entity_type: str,
    run_ctx: Dict[str, Any],
    catalog_db: str = "iceberg_db",
) -> int:
    """Writes bad records to curated bad table."""
    table_name = f"{entity_type.lower()}_bad"
    enriched = attach_metadata_columns(records, run_ctx, dq_status="BAD")
    return write_to_iceberg(spark, enriched, table_name, catalog_db=catalog_db)
