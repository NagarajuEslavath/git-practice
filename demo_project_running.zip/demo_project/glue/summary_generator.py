"""Deterministic Operational Summary Generator (No Bedrock/Network calls)."""
from __future__ import annotations

from typing import Any, Dict, List, Tuple


def build_summary(
    run_ctx: Dict[str, Any],
    stats: Dict[str, Any],
    top_failures: List[Tuple[str, int]] | None = None,
) -> str:
    """
    Produces a business-friendly operational summary paragraph.

    Args:
        run_ctx: dict containing run_id, batch_id, file_id, status, duration_seconds
        stats: dict containing total_records, good_records, bad_records, dq_score
        top_failures: list of (rule_id, count) tuples ordered by frequency descending
    """
    run_id = run_ctx.get("run_id", "N/A")
    batch_id = run_ctx.get("batch_id", "N/A")
    file_id = run_ctx.get("file_id", "N/A")
    status = run_ctx.get("status", "SUCCESS")
    duration = run_ctx.get("duration_seconds", 0.0)

    total = stats.get("total_records", 0)
    good = stats.get("good_records", 0)
    bad = stats.get("bad_records", 0)
    dq_score = stats.get("dq_score", 100.0)

    summary_lines = [
        f"WealthBridge Ingestion Run [{run_id}] completed for batch '{batch_id}' (File ID: {file_id}) with status '{status}' in {duration:.2f}s.",
        f"Processed {total} total records: {good} GOOD, {bad} BAD. Combined Data Quality Score: {dq_score:.2f}%.",
    ]

    if top_failures:
        failure_str = ", ".join([f"{rule_id} ({count} failures)" for rule_id, count in top_failures if count > 0])
        if failure_str:
            summary_lines.append(f"Top Rule Failures: {failure_str}.")
        else:
            summary_lines.append("No rule failures recorded.")
    else:
        summary_lines.append("No rule failures recorded.")

    return " ".join(summary_lines)
