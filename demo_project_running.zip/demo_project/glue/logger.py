"""Structured JSON logger for Glue jobs and pipeline components."""
from __future__ import annotations

import datetime as dt
import json
import logging
import sys
from typing import Any, Dict


class JsonFormatter(logging.Formatter):
    """Formats log records as single-line JSON objects."""

    def format(self, record: logging.LogRecord) -> str:
        log_entry: Dict[str, Any] = {
            "timestamp": dt.datetime.now(dt.timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }

        # Attach context attributes if present
        for attr in ("run_id", "batch_id", "file_id", "stage"):
            val = getattr(record, attr, None)
            if val is not None:
                log_entry[attr] = val

        if record.exc_info:
            log_entry["exception"] = self.formatException(record.exc_info)

        return json.dumps(log_entry)


class ContextAdapter(logging.LoggerAdapter):
    """LoggerAdapter that preserves execution context across log calls."""

    def process(self, msg: str, kwargs: Any) -> tuple[str, Any]:
        extra = kwargs.get("extra", {})
        merged_extra = {**self.extra, **extra}
        kwargs["extra"] = merged_extra
        return msg, kwargs

    def bind(self, **kwargs: Any) -> ContextAdapter:
        """Return a new LoggerAdapter with updated context."""
        new_extra = {**self.extra, **kwargs}
        return ContextAdapter(self.logger, new_extra)


def get_logger(
    name: str = "glue_job",
    run_id: str | None = None,
    batch_id: str | None = None,
    file_id: str | None = None,
    stage: str | None = None,
) -> ContextAdapter:
    """Returns a structured JSON logger with contextual bindings."""
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)

    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(JsonFormatter())
        logger.addHandler(handler)

    context = {
        "run_id": run_id,
        "batch_id": batch_id,
        "file_id": file_id,
        "stage": stage,
    }
    return ContextAdapter(logger, context)
