"""Configuration loader for Glue jobs and local execution."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict

import yaml
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass



@dataclass
class AWSConfig:
    region: str = "ap-south-1"


@dataclass
class S3Config:
    landing_bucket: str = "wealthbridge-landing"
    curated_bucket: str = "wealthbridge-curated"
    warehouse_prefix: str = "warehouse/"


@dataclass
class DatabaseConfig:
    host: str = "wealthbridgemetadatards.cpckkgcwoy32.ap-south-1.rds.amazonaws.com"
    port: int = 5432
    name: str = "WealthBridgeMetadataDatabase"
    user: str = "capvolt"
    password: str = field(default="", repr=False)


@dataclass
class GlueJobConfig:
    job_name: str = "wealthbridge-ingestion-job"
    catalog_name: str = "glue_catalog"
    iceberg_db: str = "iceberg_db"
    max_concurrency: int = 5
    tables: Dict[str, str] = field(default_factory=lambda: {
        "transaction_good": "transaction_good",
        "transaction_bad": "transaction_bad",
        "position_good": "position_good",
        "position_bad": "position_bad",
    })


@dataclass
class AppConfig:
    environment: str = "dev"
    aws: AWSConfig = field(default_factory=AWSConfig)
    s3: S3Config = field(default_factory=S3Config)
    database: DatabaseConfig = field(default_factory=DatabaseConfig)
    glue: GlueJobConfig = field(default_factory=GlueJobConfig)


def _deep_update(base: dict, override: dict) -> dict:
    """Recursively update dictionary base with override."""
    result = dict(base)
    for key, value in override.items():
        if isinstance(value, dict) and key in result and isinstance(result[key], dict):
            result[key] = _deep_update(result[key], value)
        else:
            result[key] = value
    return result


def resolve_db_password() -> str:
    """
    Resolves the database password at runtime.
    Checks environment variables DB_PASSWORD or RDS_PASSWORD,
    or falls back to empty string (e.g. for mock/test runs).
    Password is never loaded from git-tracked config files.
    """
    return os.getenv("DB_PASSWORD") or os.getenv("RDS_PASSWORD") or ""


def load_config(env: str = "dev", config_dir: Path | str | None = None) -> AppConfig:
    """Loads base config and environment override YAML files into typed AppConfig."""
    if config_dir is None:
        # Default to repo root config/ directory relative to this file
        config_dir = Path(__file__).resolve().parent.parent / "config"
    else:
        config_dir = Path(config_dir)

    base_path = config_dir / "config.yaml"
    raw_data: dict[str, Any] = {}

    if base_path.exists():
        with open(base_path, "r", encoding="utf-8") as f:
            raw_data = yaml.safe_load(f) or {}

    env_path = config_dir / f"config.{env}.yaml"
    if env_path.exists():
        with open(env_path, "r", encoding="utf-8") as f:
            env_data = yaml.safe_load(f) or {}
            raw_data = _deep_update(raw_data, env_data)

    aws_data = raw_data.get("aws", {})
    s3_data = raw_data.get("s3", {})
    db_data = raw_data.get("database", {})
    glue_data = raw_data.get("glue", {})

    aws_cfg = AWSConfig(region=aws_data.get("region", "ap-south-1"))
    s3_cfg = S3Config(
        landing_bucket=s3_data.get("landing_bucket", "wealthbridge-landing"),
        curated_bucket=s3_data.get("curated_bucket", "wealthbridge-curated"),
        warehouse_prefix=s3_data.get("warehouse_prefix", "warehouse/"),
    )
    db_cfg = DatabaseConfig(
        host=db_data.get("host", "wealthbridgemetadatards.cpckkgcwoy32.ap-south-1.rds.amazonaws.com"),
        port=int(db_data.get("port", 5432)),
        name=db_data.get("name", "WealthBridgeMetadataDatabase"),
        user=db_data.get("user", "capvolt"),
        password=resolve_db_password(),
    )
    glue_cfg = GlueJobConfig(
        job_name=glue_data.get("job_name", "wealthbridge-ingestion-job"),
        catalog_name=glue_data.get("catalog_name", "glue_catalog"),
        iceberg_db=glue_data.get("iceberg_db", "iceberg_db"),
        max_concurrency=int(glue_data.get("max_concurrency", 5)),
        tables=glue_data.get("tables", GlueJobConfig().tables),
    )

    return AppConfig(
        environment=raw_data.get("environment", env),
        aws=aws_cfg,
        s3=s3_cfg,
        database=db_cfg,
        glue=glue_cfg,
    )
