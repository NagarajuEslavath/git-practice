"""Data Quality Rule Engine module."""
from __future__ import annotations

from typing import Any, Dict, List, Set, Tuple

from glue.rule_loader import Rule
from glue.validators import evaluate_rule_on_row


def _get_duplicate_keys(rows: List[Dict[str, Any]], rules: List[Rule]) -> Dict[str, Set[Any]]:
    """Identifies duplicated column values for UNIQUE rules."""
    dup_map: Dict[str, Set[Any]] = {}
    for rule in rules:
        if rule.rule_type.upper() == "UNIQUE" and rule.column_name:
            col = rule.column_name
            counts: Dict[Any, int] = {}
            for r in rows:
                val = r.get(col)
                if val is not None and str(val).strip() != "":
                    counts[val] = counts.get(val, 0) + 1
            dup_map[col] = {k for k, count in counts.items() if count > 1}
    return dup_map


def apply_rules(
    df: Any,
    rules: List[Rule],
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], Dict[str, int]]:
    """
    Applies rules to records and splits them into good_records and bad_records.

    Returns:
        (good_records, bad_records, failure_counts)
    """
    # Extract records list
    if hasattr(df, "_df"):
        # LocalDataFrameWrapper around pandas
        raw_rows = df._df.to_dict(orient="records")
    elif hasattr(df, "collect"):
        # PySpark DataFrame
        raw_rows = [row.asDict() for row in df.collect()]
    elif isinstance(df, list):
        raw_rows = df
    else:
        raw_rows = []

    dup_map = _get_duplicate_keys(raw_rows, rules)

    good_records: List[Dict[str, Any]] = []
    bad_records: List[Dict[str, Any]] = []
    failure_counts: Dict[str, int] = {rule.rule_id: 0 for rule in rules}

    for row in raw_rows:
        failed_rule_ids: List[str] = []
        failure_reasons: List[str] = []
        is_bad = False

        for rule in rules:
            col = rule.column_name or ""
            dup_keys = dup_map.get(col, set())
            is_valid, err_msg = evaluate_rule_on_row(rule, row, dup_keys)

            if not is_valid:
                failure_counts[rule.rule_id] = failure_counts.get(rule.rule_id, 0) + 1
                if rule.severity.upper() == "CRITICAL":
                    is_bad = True
                    failed_rule_ids.append(rule.rule_id)
                    failure_reasons.append(err_msg)

        if is_bad:
            bad_row = dict(row)
            bad_row["dq_status"] = "BAD"
            bad_row["failed_rule_id"] = ",".join(failed_rule_ids)
            bad_row["failure_reason"] = " | ".join(failure_reasons)
            bad_records.append(bad_row)
        else:
            good_row = dict(row)
            good_row["dq_status"] = "GOOD"
            good_row["failed_rule_id"] = None
            good_row["failure_reason"] = None
            good_records.append(good_row)

    return good_records, bad_records, failure_counts


def calculate_dq_score(total_good: int, total_records: int) -> float:
    """Calculates DQ score percentage: good_records / total_records * 100."""
    if total_records == 0:
        return 100.0
    return round((total_good / total_records) * 100.0, 2)
