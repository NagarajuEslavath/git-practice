"""Metadata writer module for PostgreSQL ingestion metadata tables."""
from __future__ import annotations

import datetime as dt
from typing import Any, Dict, List, Optional, Tuple

try:
    import psycopg2
except ImportError:
    psycopg2 = None



def record_ingestion_run_start(
    conn: Any,
    run_id: str,
    batch_id: str,
    file_id: str,
) -> bool:
    """Inserts an initial record into ingestion_run with status='RUNNING'."""
    if conn is None:
        return False
    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO ingestion_run (run_id, batch_id, file_id, start_time, status)
                VALUES (%s, %s, %s, now(), 'RUNNING')
                ON CONFLICT (run_id) DO NOTHING;
                """,
                (run_id, batch_id, file_id),
            )
        conn.commit()
        return True
    except Exception as err:
        conn.rollback()
        print(f"[metadata_writer_warning] Could not record run start: {err}")
        return False


def update_ingestion_run_finish(
    conn: Any,
    run_id: str,
    duration_seconds: float,
    total_records: int,
    good_records: int,
    bad_records: int,
    dq_score: float,
    status: str,
    summary: str,
) -> bool:
    """Updates ingestion_run row with end_time, duration, counts, dq_score, status, and summary."""
    if conn is None:
        return False
    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE ingestion_run
                SET end_time = now(),
                    duration_seconds = %s,
                    total_records = %s,
                    good_records = %s,
                    bad_records = %s,
                    dq_score = %s,
                    status = %s,
                    summary = %s
                WHERE run_id = %s;
                """,
                (duration_seconds, total_records, good_records, bad_records, dq_score, status, summary, run_id),
            )
        conn.commit()
        return True
    except Exception as err:
        conn.rollback()
        print(f"[metadata_writer_warning] Could not update run finish: {err}")
        return False


def record_source_file(
    conn: Any,
    run_id: str,
    file_name: str,
    file_type: str,
    s3_path: str,
    batch_id: str,
    file_id: str,
    record_count: int,
    good_count: int,
    bad_count: int,
    processing_status: str = "PROCESSED",
) -> bool:
    """Inserts a row into source_file."""
    if conn is None:
        return False
    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO source_file
                    (run_id, file_name, file_type, s3_path, batch_id, file_id, record_count, good_count, bad_count, processing_status)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s);
                """,
                (run_id, file_name, file_type, s3_path, batch_id, file_id, record_count, good_count, bad_count, processing_status),
            )
        conn.commit()
        return True
    except Exception as err:
        conn.rollback()
        print(f"[metadata_writer_warning] Could not record source file: {err}")
        return False


def record_rule_failure_summary(
    conn: Any,
    run_id: str,
    batch_id: str,
    file_id: str,
    entity_type: str,
    failure_counts: Dict[str, int],
) -> bool:
    """
    Inserts per-rule failure counts into dq_rule_failure_summary.
    Looks up numerical rule_id from dq_rule_registry using rule_code.
    """
    if conn is None or not failure_counts:
        return False
    try:
        with conn.cursor() as cur:
            for rule_code, count in failure_counts.items():
                if count > 0:
                    # Resolve rule_id from rule_code
                    cur.execute("SELECT rule_id FROM dq_rule_registry WHERE rule_code = %s;", (rule_code,))
                    res = cur.fetchone()
                    if res:
                        rule_id_num = res[0]
                        cur.execute(
                            """
                            INSERT INTO dq_rule_failure_summary
                                (run_id, batch_id, file_id, rule_id, entity_type, failure_count)
                            VALUES (%s, %s, %s, %s, %s, %s)
                            ON CONFLICT (run_id, rule_id, entity_type)
                            DO UPDATE SET failure_count = EXCLUDED.failure_count;
                            """,
                            (run_id, batch_id, file_id, rule_id_num, entity_type, count),
                        )
        conn.commit()
        return True
    except Exception as err:
        conn.rollback()
        print(f"[metadata_writer_warning] Could not record failure summary: {err}")
        return False
