"""Rule loader module for DQ registry rules."""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class Rule:
    rule_id: str
    rule_name: str
    entity_type: str
    rule_type: str
    column_name: Optional[str]
    parameters: Dict[str, Any]
    error_message: str
    severity: str
    active_flag: bool = True


def _parse_sql_seed_rules(sql_path: Path) -> List[Rule]:
    """Fallback rule parser reading seeded INSERT statements from 06_seed_dq_rules.sql."""
    rules: List[Rule] = []
    if not sql_path.exists():
        return rules

    content = sql_path.read_text(encoding="utf-8")

    # Regular expression matching individual tuple values in INSERT statement
    tuple_pattern = re.compile(
        r"\(\s*'([^']+)',\s*'([^']+)',\s*'([^']+)',\s*'([^']+)',\s*'([^']+)',\s*(NULL|'(?:''|[^'])*'),\s*'([^']+)',\s*'([^']+)'\s*\)",
        re.IGNORECASE,
    )


    for match in tuple_pattern.finditer(content):
        rule_code, entity_type, rule_name, rule_type, target_col, rule_expr_raw, data_type, severity = match.groups()
        rule_expr = None if rule_expr_raw.upper() == "NULL" else rule_expr_raw.strip("'").replace("''", "'")

        params: Dict[str, Any] = {}
        rule_type_upper = rule_type.upper()

        if rule_type_upper == "ALLOWED_VALUES" and rule_expr:
            params["allowed_values"] = [v.strip() for v in rule_expr.split(",")]
        elif rule_type_upper == "EXPRESSION" and rule_expr:
            params["expression"] = rule_expr

        rules.append(
            Rule(
                rule_id=rule_code,
                rule_name=rule_name,
                entity_type=entity_type.upper(),
                rule_type=rule_type_upper,
                column_name=target_col,
                parameters=params,
                error_message=rule_name,  # Default error message to rule_name
                severity=severity.upper(),
                active_flag=True,
            )
        )

    return rules


def load_active_rules(
    conn: Any = None,
    entity_type: str = "TRANSACTION",
    sql_seed_path: Path | str | None = None,
) -> List[Rule]:
    """
    Loads active rules (active_flag = True) for entity_type.
    If database connection `conn` is provided, queries dq_rule_registry table.
    Otherwise falls back to parsing sql/06_seed_dq_rules.sql.
    """
    rules: List[Rule] = []

    if conn is not None:
        try:
            cursor = conn.cursor()
            query = """
                SELECT rule_code, rule_name, entity_type, rule_type, target_column,
                       rule_expression, severity, active_flag
                FROM dq_rule_registry
                WHERE entity_type = %s AND active_flag = true
                ORDER BY rule_id;
            """
            cursor.execute(query, (entity_type.upper(),))
            rows = cursor.fetchall()
            for r in rows:
                rule_code, rule_name, ent, rtype, target_col, rule_expr, sev, active = r[:8]
                params: Dict[str, Any] = {}
                rtype_upper = rtype.upper()
                if rtype_upper == "ALLOWED_VALUES" and rule_expr:
                    params["allowed_values"] = [v.strip() for v in rule_expr.split(",")]
                elif rtype_upper == "EXPRESSION" and rule_expr:
                    params["expression"] = rule_expr

                rules.append(
                    Rule(
                        rule_id=rule_code,
                        rule_name=rule_name,
                        entity_type=ent,
                        rule_type=rtype_upper,
                        column_name=target_col,
                        parameters=params,
                        error_message=rule_name,
                        severity=sev,
                        active_flag=active,
                    )
                )
            return rules
        except Exception as err:
            print(f"[rule_loader_warning] Could not load rules from DB connection: {err}")

    # Fallback to 06_seed_dq_rules.sql
    if sql_seed_path is None:
        sql_seed_path = Path(__file__).resolve().parent.parent / "sql" / "06_seed_dq_rules.sql"
    else:
        sql_seed_path = Path(sql_seed_path)

    all_seed_rules = _parse_sql_seed_rules(sql_seed_path)
    rules = [
        r for r in all_seed_rules
        if r.entity_type == entity_type.upper() and r.active_flag
    ]
    return rules
