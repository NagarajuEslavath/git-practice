# WealthBridge Financial Data Platform — Continuation Plan (Phases 4–9)

**Handoff document for Google Antigravity (or any agentic IDE).**
Drop this file at the repo root. It is the single source of truth for finishing
the project. Everything an agent needs — locked decisions, config, file specs,
and verifiable acceptance criteria — is here.

---

## 1. How to drive this in Antigravity

- Open the repo as a Workspace so the agent indexes the existing `sql/` and
  `sample_data/` folders and this plan.
- Use **Agent-Assisted (checkpoint) mode**, not full autonomy. This is financial
  code; approve at each phase boundary.
- Feed **one phase at a time** using the "Antigravity task prompt" block at the
  end of each phase below. Do not ask it to do Phases 4–9 in one shot.
- After each phase, run that phase's **Acceptance criteria** as the verification
  gate before moving on. Several criteria are executable — let the agent run them
  in its terminal surface and show you the output.
- **Never let it commit secrets.** The RDS password is supplied at runtime via a
  Glue Connection, not in code. Keep `config/secrets*.yaml` in `.gitignore`.

---

## 2. Status snapshot

| Phase | Deliverable | Status |
|------:|-------------|--------|
| 1 | Architecture, folder structure, tech rationale | ✅ Done |
| 2 | PostgreSQL schema + seed (`sql/00`–`06`, `99`) | ✅ Done, validated on PG16 |
| 3 | Sample CSVs + validation oracle (`sample_data/`) | ✅ Done, 16/16 rule coverage |
| 4 | Glue project scaffold (config, logging, reader, orchestration) | ⏳ Next |
| 5 | DQ rule engine (validators, casting, good/bad split) | ⏳ |
| 6 | Iceberg writer (4 tables + metadata columns) | ⏳ |
| 7 | Metadata writer + Python summary generator (Bedrock replacement) | ⏳ |
| 8 | Testing & validation (unit + oracle cross-check) | ⏳ |
| 9 | Documentation + SAM infra + the two Lambdas | ⏳ |

---

## 3. Locked design contract (do not change without asking the owner)

1. **No Amazon Bedrock.** Operational summaries are generated deterministically in
   Python (`summary_generator.py`) and stored in `ingestion_run.summary`.
2. **One Glue job** processes both entities via a single dynamic code path.
3. **Processing unit = file id.** One file id = exactly one TRANSACTION file + one
   POSITION file = one Glue run. Many file ids → many small near-real-time runs.
4. **Push orchestration.** S3 `ObjectCreated` → preprocessor Lambda → when both
   files of a file id are registered and not already processed, it calls
   `glue.start_job_run` with `--batch_id` and `--file_id`.
5. **Anti-reprocess** lives in the `file_manifest` table (unique on
   `(s3_bucket, s3_key)`); files are never moved, only S3-tagged.
6. **Filename format** `batch{N}_{fileid}_{name}.csv`, e.g.
   `batch1_1234_transcation12.csv`. Entity is fuzzy-matched from token 3
   (`trans*` → TRANSACTION, `posit*` → POSITION; handles the `transcation`
   misspelling and trailing digits). Unmatched → tag `Rejected`, never sent to Glue.
7. **Schema handling:** infer columns from the CSV header, then **cast** only the
   columns a rule references, to that rule's `expected_data_type`. An EXPRESSION
   rule's columns must all share one type.
8. **Rule engine is config-driven** from `dq_rule_registry`. Rule types:
   `NOT_NULL`, `UNIQUE` (within-batch), `ALLOWED_VALUES` (CSV allow-list),
   `EXPRESSION` (Spark SQL boolean; TRUE = good). Evaluate via Spark `expr()`,
   never Python `eval`.
9. **Bad-record capture:** one row per bad record, with **all** failed rules
   captured (`failed_rule_id` = comma-joined codes, `failure_reason` = joined
   messages). A separate exploded count feeds `dq_rule_failure_summary`.
10. **Within-batch uniqueness rejects all copies** of a duplicated ID (no
    "keep first" survivor) — unless the owner flips this (see §9 Open decisions).
11. **DQ score** = `good_records / total_records * 100`, single combined score
    per run across both entities.
12. **Severity:** `CRITICAL` failure → record is BAD; `WARNING` → counted only,
    record stays GOOD.

---

## 4. Environment & configuration values

| Key | Value |
|-----|-------|
| AWS region | `ap-south-1` |
| Landing bucket | `wealthbridge-landing` |
| Curated bucket | `wealthbridge-curated` |
| Glue catalog database (Iceberg) | `iceberg_db` |
| RDS endpoint | `wealthbridgemetadatards.cpckkgcwoy32.ap-south-1.rds.amazonaws.com` |
| RDS port | `5432` |
| RDS database | `WealthBridgeMetadataDatabase` |
| RDS user | `capvolt` |
| RDS password | **runtime only** via Glue Connection / gitignored config — never in Git. Rotate the exposed value. |

Config lives as declarative YAML in `config/` (`config.yaml` base +
`config.dev.yaml` / `config.prod.yaml` overrides). `glue/config.py` loads and
validates it into typed objects. No literals in logic files.

---

## 5. Canonical columns (must match the seeded rules and sample CSVs)

- **transactions:** `transaction_id, account_id, transaction_type, trade_date,
  settlement_date, quantity, price, amount, currency`
- **positions:** `position_id, account_id, position_date, quantity_held,
  market_value, currency`

Iceberg metadata columns appended to every curated table:
`ingestion_run_id, batch_id, source_file, dq_status, failed_rule_id,
failure_reason, processed_timestamp`.

---

## 6. Target repository structure

```
financial-data-platform/
├── CONTINUATION_PLAN.md          # this file
├── README.md                     # Phase 9
├── requirements.txt              # Phase 4
├── template.yaml                 # Phase 9 (SAM)
├── .gitignore                    # Phase 4 (must ignore config/secrets*.yaml)
├── config/
│   ├── config.yaml   config.dev.yaml   config.prod.yaml     # Phase 4
├── sql/                          # ✅ done (00–06, 99)
├── glue/
│   ├── main.py  config.py  logger.py  utils.py  reader.py   # Phase 4
│   ├── rule_loader.py                                       # Phase 4/5
│   ├── validators.py  dq_engine.py                          # Phase 5
│   ├── iceberg_writer.py                                    # Phase 6
│   ├── metadata_writer.py  summary_generator.py             # Phase 7
├── lambdas/
│   ├── preprocessor/app.py                                  # Phase 9 (or earlier)
│   └── notifier/app.py                                      # Phase 9 (stub)
├── sample_data/                  # ✅ done
├── tests/                        # Phase 8
└── docs/                         # Phase 9
```

---

## 7. Remaining phases

### Phase 4 — Glue project scaffold

**Goal:** the runnable skeleton the engine/writer plug into. No DQ logic yet.

**Files & responsibilities**
- `requirements.txt` — pyspark (matched to Glue 4.0 / Spark 3.3), boto3,
  psycopg2-binary, pyyaml, pytest. Note Iceberg is provided by Glue at runtime.
- `.gitignore` — ignore `config/secrets*.yaml`, `__pycache__`, `.pytest_cache`.
- `config/config.yaml` (+ dev/prod) — region, buckets, `iceberg_db`, RDS conn
  fields (host/port/db/user; password sourced at runtime), Glue job name,
  catalog name, table names, max concurrency.
- `glue/config.py` — `load_config(env: str) -> AppConfig` typed dataclasses;
  validates required keys; resolves the RDS password from the Glue Connection /
  env at runtime, never from a committed file.
- `glue/logger.py` — `get_logger(name) -> logging.Logger`, structured JSON lines
  (run_id, batch_id, file_id, stage, message) to CloudWatch/stdout.
- `glue/utils.py` — `parse_filename(key) -> ParsedFile|None` (batch_id, file_id,
  entity_type via fuzzy match); `new_run_id(batch_id, file_id) -> str`;
  `tag_s3_object(bucket, key, status)`; `read_job_args()`.
- `glue/reader.py` — `read_entity_csv(spark, s3_path) -> DataFrame` header-inferred
  as strings; `resolve_batch_files(batch_id, file_id) -> {TRANSACTION, POSITION}`.
- `glue/rule_loader.py` — `load_active_rules(conn, entity_type) -> list[Rule]`
  from `dq_rule_registry`.
- `glue/main.py` — orchestration: read args → get rules → read files →
  (placeholder) validate → (placeholder) write → update metadata → tag S3 →
  finish. Wrap each entity in try/except so one failure can't crash the other
  (status `PARTIAL`).

**Acceptance criteria**
- `python -c "import glue.config, glue.utils, glue.reader, glue.logger"` imports clean.
- `parse_filename('batch1_1234_transcation12.csv')` → `('batch1','1234','TRANSACTION')`;
  `...position21.csv` → POSITION; `bad.csv` → None.
- `read_entity_csv` on the Phase-3 sample returns 24 transaction / 19 position rows,
  all string-typed, with the canonical headers.
- `main.py` runs end-to-end against sample data as a no-op pipeline (reads, logs
  stages, no writes) without error.

**Antigravity task prompt**
> Implement Phase 4 per CONTINUATION_PLAN.md §7. Create the config layer, logger,
> utils (filename parser + S3 tagging + run id), reader (header-inferred CSV),
> rule_loader, and a main.py orchestration skeleton with per-entity try/except.
> No DQ logic yet. Then run the Phase 4 acceptance criteria in the terminal and
> show me the output.

---

### Phase 5 — DQ rule engine

**Goal:** execute registry rules dynamically; split good/bad; capture all failures.

**Files & responsibilities**
- `glue/validators.py` — pure builders returning Spark boolean `Column`s:
  `not_null(col)`, `is_unique_in_batch(df, col)`, `in_allowed(col, values)`,
  `expression(expr_str)`. Plus `cast_columns(df, rules) -> df` applying each rule's
  `expected_data_type` to its referenced columns (parse identifiers from EXPRESSION).
- `glue/dq_engine.py` — `apply_rules(df, rules) -> (good_df, bad_df, failures)`:
  build a per-rule boolean column; a record is BAD if any CRITICAL rule is false;
  attach `failed_rule_id` (comma-joined codes) and `failure_reason` (joined
  messages) to bad rows; return per-(rule,entity) failure counts.

**Acceptance criteria**
- Run against Phase-3 samples and compare to the oracle
  (`sample_data/generate_and_validate.py`): **transactions 12 good / 12 bad,
  positions 10 good / 9 bad**, combined DQ score **51.16%**.
- `TXN0022` and `POS0017` each appear once in the bad set with **three** rule
  codes in `failed_rule_id`.
- Both copies of `TXN0013` / `POS0011` are BAD (uniqueness rejects all copies).
- Adding a new rule row to `dq_rule_registry` changes behavior with **no** code change.

**Antigravity task prompt**
> Implement Phase 5 per §7: validators (including the cast layer) and dq_engine
> (good/bad split with all failures captured per record). Verify by running the
> engine on sample_data and asserting the counts match
> sample_data/generate_and_validate.py exactly (12/12, 10/9, 51.16%). Show the diff.

---

### Phase 6 — Iceberg writer

**Goal:** write curated good/bad tables to S3 via the Glue Catalog.

**Files & responsibilities**
- `glue/iceberg_writer.py` — configure Spark for Iceberg + Glue Catalog
  (`iceberg_db`); create if absent and append to `transaction_good`,
  `transaction_bad`, `position_good`, `position_bad`; add the seven metadata
  columns from §5; partition curated tables by `batch_id`.
  Provide `write_good(df, entity, run_ctx)` / `write_bad(df, entity, run_ctx)`.
- Spark session config documented for the Glue job (catalog impl, warehouse =
  `s3://wealthbridge-curated/warehouse/`).

**Acceptance criteria**
- Against sample data, four tables receive the expected row counts and every row
  carries `ingestion_run_id`, `batch_id`, `source_file`, `processed_timestamp`;
  bad tables also carry non-null `dq_status='BAD'`, `failed_rule_id`,
  `failure_reason`.
- Re-running the same run id does not double-write (idempotent per run — use
  overwrite-by-run or a pre-delete of that run's partition; see §9).
- Schema evolution: adding a column to the source doesn't break the append.

**Antigravity task prompt**
> Implement Phase 6 per §7: iceberg_writer.py writing the four tables through the
> Glue Catalog (iceberg_db) with the seven metadata columns, partitioned by
> batch_id. Document the Spark/Iceberg session config for the Glue job. Verify the
> four tables and metadata columns against sample data locally if an Iceberg runtime
> is available, otherwise provide the exact glue-job command to validate in AWS.

---

### Phase 7 — Metadata writer + Python summary generator

**Goal:** persist run/file/failure metadata and the deterministic summary.

**Files & responsibilities**
- `glue/metadata_writer.py` — psycopg2 upserts into `ingestion_run` (start/end,
  durations, counts, dq_score, status), `source_file` (per file), and
  `dq_rule_failure_summary` (from engine counts). Transactional; safe re-run.
- `glue/summary_generator.py` — `build_summary(run_ctx, stats, top_failures) -> str`
  producing a business-friendly paragraph (run id, batch id, files, totals, DQ
  score, top-N failed rules, status, execution time). Pure function, no AWS calls.
  Write result into `ingestion_run.summary`.

**Acceptance criteria**
- After a sample run, `ingestion_run` has one row with correct counts and
  `dq_score = 51.16`; `source_file` has two rows; `dq_rule_failure_summary` has one
  row per rule that fired with correct counts.
- `build_summary` is deterministic (same input → identical string) and names the
  top failed rules by count.
- No network/model calls anywhere in the summary path.

**Antigravity task prompt**
> Implement Phase 7 per §7: metadata_writer.py (idempotent psycopg2 writes to the
> three tables) and summary_generator.py (deterministic operational summary, no
> Bedrock). Verify against the seeded PG schema using a sample run; show the
> resulting ingestion_run row and summary text.

---

### Phase 8 — Testing & validation

**Goal:** independent proof the pipeline is correct.

**Files & responsibilities**
- `tests/conftest.py` — local SparkSession + a temp SQLite/PG fixture seeded from `sql/`.
- `tests/test_validators.py`, `test_dq_engine.py` — unit tests per rule type; the
  **oracle cross-check** asserting engine output equals
  `generate_and_validate.py` for the sample set.
- `tests/test_rule_loader.py` — loads/filters active rules; new rule picked up.
- `tests/test_summary_generator.py` — determinism + top-failure ordering.

**Acceptance criteria**
- `pytest -q` green; oracle cross-check passes (12/12, 10/9, 51.16%).
- A negative test: deactivating a rule (`active_flag=false`) removes its failures.

**Antigravity task prompt**
> Implement Phase 8 per §7: pytest suite with a Spark fixture and a PG/SQLite
> fixture seeded from sql/. Include the oracle cross-check against
> generate_and_validate.py. Run pytest and show a green result.

---

### Phase 9 — Documentation, SAM infra, and the two Lambdas

**Goal:** deployable stack + handover docs.

**Files & responsibilities**
- `lambdas/preprocessor/app.py` — S3-event handler: parse filename, reject
  malformed, `INSERT ... ON CONFLICT DO NOTHING` into `file_manifest`, run the
  completeness check (both entity types present & unprocessed), transactionally
  mark `TRIGGERED`, call `glue.start_job_run(--batch_id,--file_id)`.
- `lambdas/notifier/app.py` — reads `ingestion_run.summary`; **stubbed sink**
  (logs to CloudWatch) behind a pluggable interface for future SNS/email/Slack.
- `template.yaml` (SAM) — buckets + S3 notification, both Lambdas, the Glue job,
  a **Glue Connection** holding RDS creds, IAM roles (least privilege), Glue job
  max-concurrency. RDS is an existing resource → pass ARN/endpoint as a parameter,
  do not create it.
- `docs/` — architecture, deployment_guide, execution_steps, rule_engine,
  metadata_flow, iceberg_flow, validation_strategy, future_improvements.
- `README.md` — overview, structure, quickstart, run instructions.

**Acceptance criteria**
- `sam validate` passes; `sam build` succeeds.
- Preprocessor unit test: two files for one file id → exactly one `start_job_run`;
  a duplicate S3 event → no second trigger; malformed name → `REJECTED`, no trigger.
- Notifier runs against a sample summary and logs it (stub).
- Docs cover every item in the original deliverables list.

**Antigravity task prompt**
> Implement Phase 9 per §7: the preprocessor Lambda (manifest + completeness +
> push trigger), the stubbed notifier Lambda, a SAM template.yaml (buckets,
> Lambdas, Glue job, Glue Connection, least-privilege IAM, RDS as a parameter),
> and the docs/ set. Run `sam validate` and the preprocessor unit tests; show results.

---

## 8. End-to-end verification (after Phase 9)

1. Deploy stack to `ap-south-1`.
2. Upload `sample_data/batch1_1234_transcation12.csv` and
   `..._position21.csv` to `wealthbridge-landing`.
3. Expect: manifest gets two rows → one Glue run triggered → four Iceberg tables
   written → `ingestion_run` row with `dq_score = 51.16` and a summary →
   S3 objects re-tagged `Completed` → notifier logs the summary.
4. Re-upload the same files → no reprocessing (manifest dedupe).

---

## 9. Open decisions to confirm with the owner before coding the affected phase

- **Duplicate survivor policy** (Phase 5): reject *all* copies of a duplicated ID
  (current) vs keep the first occurrence as good.
- **Re-delivery of a corrected file id** (Phase 6): reject as duplicate (current)
  vs reprocess and overwrite that run's Iceberg rows.
- **Currency allow-list** (already seeded 10 ISO codes): extend, or move to a
  reference table.
- **Iceberg idempotency mechanism** (Phase 6): overwrite-by-`batch_id` partition
  vs pre-delete of the run's rows vs MERGE.

---

## 10. Guardrails

- No secrets in Git. Password via Glue Connection at runtime; rotate the exposed one.
- IAM least privilege per role (Lambda: S3 read/tag + Glue start + RDS; Glue:
  S3 curated read/write + Catalog + RDS + CloudWatch).
- Set Glue job max concurrency so a burst of file ids queues rather than
  overwhelming account limits.
- Keep the single-Glue-job, config-driven-rules, no-Bedrock contract intact.
