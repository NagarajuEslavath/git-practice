"""Unit tests for rule loader module."""
from __future__ import annotations

from glue.rule_loader import load_active_rules


def test_rule_loader_seed_fallback():
    txn_rules = load_active_rules(entity_type="TRANSACTION")
    pos_rules = load_active_rules(entity_type="POSITION")

    assert len(txn_rules) == 9
    assert len(pos_rules) == 7

    txn_codes = [r.rule_id for r in txn_rules]
    assert "TXN_TRANSACTION_ID_NOT_NULL" in txn_codes
    assert "TXN_TRANSACTION_ID_UNIQUE" in txn_codes
    assert "TXN_ACCOUNT_ID_PREFIX" in txn_codes
