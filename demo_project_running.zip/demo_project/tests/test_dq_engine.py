"""Unit tests and Oracle cross-check for DQ Rule Engine."""
from __future__ import annotations

from pathlib import Path
from glue.dq_engine import apply_rules, calculate_dq_score
from glue.reader import read_entity_csv
from glue.rule_loader import load_active_rules


def test_oracle_cross_check(sample_data_dir: Path):
    """
    Oracle cross-check: verifies engine output against generate_and_validate.py assertions:
    - Transactions: 12 good / 12 bad
    - Positions: 10 good / 9 bad
    - Combined DQ Score: 51.16%
    """
    txn_file = str(sample_data_dir / "batch1_1234_transcation12.csv")
    pos_file = str(sample_data_dir / "batch1_1234_position21.csv")

    df_txn = read_entity_csv(None, txn_file)
    df_pos = read_entity_csv(None, pos_file)

    txn_rules = load_active_rules(entity_type="TRANSACTION")
    pos_rules = load_active_rules(entity_type="POSITION")

    tg, tb, _ = apply_rules(df_txn, txn_rules)
    pg, pb, _ = apply_rules(df_pos, pos_rules)

    assert len(tg) == 12, f"Expected 12 good transactions, got {len(tg)}"
    assert len(tb) == 12, f"Expected 12 bad transactions, got {len(tb)}"

    assert len(pg) == 10, f"Expected 10 good positions, got {len(pg)}"
    assert len(pb) == 9, f"Expected 9 bad positions, got {len(pb)}"

    total_good = len(tg) + len(pg)
    total_records = len(tg) + len(tb) + len(pg) + len(pb)
    dq_score = calculate_dq_score(total_good, total_records)

    assert dq_score == 51.16, f"Expected DQ score 51.16, got {dq_score}"


def test_multi_failure_capture(sample_data_dir: Path):
    """Verifies multi-failure records TXN0022 and POS0017 capture 3 rule codes in failed_rule_id."""
    txn_file = str(sample_data_dir / "batch1_1234_transcation12.csv")
    pos_file = str(sample_data_dir / "batch1_1234_position21.csv")

    df_txn = read_entity_csv(None, txn_file)
    df_pos = read_entity_csv(None, pos_file)

    txn_rules = load_active_rules(entity_type="TRANSACTION")
    pos_rules = load_active_rules(entity_type="POSITION")

    _, tb, _ = apply_rules(df_txn, txn_rules)
    _, pb, _ = apply_rules(df_pos, pos_rules)

    txn22 = [r for r in tb if r.get("transaction_id") == "TXN0022"][0]
    pos17 = [r for r in pb if r.get("position_id") == "POS0017"][0]

    assert len(txn22["failed_rule_id"].split(",")) == 3
    assert len(pos17["failed_rule_id"].split(",")) == 3
