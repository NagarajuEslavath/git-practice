"""Unit tests for summary generator module."""
from __future__ import annotations

from glue.summary_generator import build_summary


def test_summary_generator_determinism():
    run_ctx = {
        "run_id": "RUN_batch1_1234_20260101",
        "batch_id": "batch1",
        "file_id": "1234",
        "status": "COMPLETED",
        "duration_seconds": 12.34,
    }
    stats = {
        "total_records": 43,
        "good_records": 22,
        "bad_records": 21,
        "dq_score": 51.16,
    }
    top_failures = [("TXN_TRANSACTION_ID_UNIQUE", 3), ("POS_POSITION_ID_UNIQUE", 3)]

    s1 = build_summary(run_ctx, stats, top_failures)
    s2 = build_summary(run_ctx, stats, top_failures)

    assert s1 == s2
    assert "RUN_batch1_1234_20260101" in s1
    assert "51.16%" in s1
    assert "TXN_TRANSACTION_ID_UNIQUE (3 failures)" in s1
