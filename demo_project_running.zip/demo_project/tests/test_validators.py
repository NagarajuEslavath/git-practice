"""Unit tests for DQ rule validators."""
from __future__ import annotations

from glue.rule_loader import Rule
from glue.validators import evaluate_rule_on_row


def test_not_null_validator():
    rule = Rule(
        rule_id="TXN_TRANSACTION_ID_NOT_NULL",
        rule_name="Transaction ID must not be null",
        entity_type="TRANSACTION",
        rule_type="NOT_NULL",
        column_name="transaction_id",
        parameters={},
        error_message="Transaction ID is required",
        severity="CRITICAL",
    )

    valid_row = {"transaction_id": "TXN0001"}
    invalid_row = {"transaction_id": ""}

    is_valid, _ = evaluate_rule_on_row(rule, valid_row, set())
    assert is_valid is True

    is_valid, err = evaluate_rule_on_row(rule, invalid_row, set())
    assert is_valid is False
    assert err == "Transaction ID is required"


def test_unique_validator():
    rule = Rule(
        rule_id="TXN_TRANSACTION_ID_UNIQUE",
        rule_name="Transaction ID must be unique within batch",
        entity_type="TRANSACTION",
        rule_type="UNIQUE",
        column_name="transaction_id",
        parameters={},
        error_message="Duplicate transaction_id",
        severity="CRITICAL",
    )

    dup_keys = {"TXN0013"}

    row_clean = {"transaction_id": "TXN0001"}
    row_dup = {"transaction_id": "TXN0013"}

    is_valid, _ = evaluate_rule_on_row(rule, row_clean, dup_keys)
    assert is_valid is True

    is_valid, err = evaluate_rule_on_row(rule, row_dup, dup_keys)
    assert is_valid is False
    assert err == "Duplicate transaction_id"


def test_allowed_values_validator():
    rule = Rule(
        rule_id="TXN_TYPE_ALLOWED",
        rule_name="Transaction type allowed values",
        entity_type="TRANSACTION",
        rule_type="ALLOWED_VALUES",
        column_name="transaction_type",
        parameters={"allowed_values": ["BUY", "SELL", "DIVIDEND", "TRANSFER"]},
        error_message="Invalid transaction type",
        severity="CRITICAL",
    )

    valid_row = {"transaction_type": "BUY"}
    invalid_row = {"transaction_type": "SHORT"}

    is_valid, _ = evaluate_rule_on_row(rule, valid_row, set())
    assert is_valid is True

    is_valid, err = evaluate_rule_on_row(rule, invalid_row, set())
    assert is_valid is False
    assert err == "Invalid transaction type"
