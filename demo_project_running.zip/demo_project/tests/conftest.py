"""Pytest configuration and shared fixtures for WealthBridge platform."""
from __future__ import annotations

from pathlib import Path
import pytest

from glue.rule_loader import load_active_rules


@pytest.fixture
def sql_dir() -> Path:
    return Path(__file__).resolve().parent.parent / "sql"


@pytest.fixture
def sample_data_dir() -> Path:
    return Path(__file__).resolve().parent.parent / "sample_data"


@pytest.fixture
def txn_rules() -> list:
    return load_active_rules(entity_type="TRANSACTION")


@pytest.fixture
def pos_rules() -> list:
    return load_active_rules(entity_type="POSITION")
