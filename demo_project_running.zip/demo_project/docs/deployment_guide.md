# Deployment Guide — WealthBridge Data Platform

## Prerequisites
- AWS CLI configured for region `ap-south-1`.
- AWS SAM CLI installed (`sam --version`).
- Python 3.12+ and PySpark 3.3.

## Steps
1. **Initialize Metadata Schema**:
   Execute SQL scripts in `sql/` against the target PostgreSQL RDS database:
   ```bash
   psql -h <RDS_HOST> -U capvolt -d WealthBridgeMetadataDatabase -f sql/00_common.sql
   psql -h <RDS_HOST> -U capvolt -d WealthBridgeMetadataDatabase -f sql/01_create_ingestion_run.sql
   psql -h <RDS_HOST> -U capvolt -d WealthBridgeMetadataDatabase -f sql/02_create_file_manifest.sql
   psql -h <RDS_HOST> -U capvolt -d WealthBridgeMetadataDatabase -f sql/03_create_source_file.sql
   psql -h <RDS_HOST> -U capvolt -d WealthBridgeMetadataDatabase -f sql/04_create_dq_rule_registry.sql
   psql -h <RDS_HOST> -U capvolt -d WealthBridgeMetadataDatabase -f sql/05_create_dq_rule_failure_summary.sql
   psql -h <RDS_HOST> -U capvolt -d WealthBridgeMetadataDatabase -f sql/06_seed_dq_rules.sql
   ```

2. **Build and Deploy Infrastructure**:
   ```bash
   sam build
   sam deploy --guided
   ```
