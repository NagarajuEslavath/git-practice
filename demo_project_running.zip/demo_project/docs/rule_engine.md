# Data Quality Rule Engine Specification

## Supported Rule Types
1. `NOT_NULL`: Ensures column is not null or empty string.
2. `UNIQUE`: Ensures within-batch uniqueness for target column. Reject all duplicate copies.
3. `ALLOWED_VALUES`: CSV allow-list validation (e.g. ISO currencies).
4. `EXPRESSION`: Spark SQL boolean expression evaluating to TRUE for good records.

## Severity & Good/Bad Split
- `CRITICAL`: Any failure classifies record as BAD. Failed rule IDs and failure reasons are captured into `failed_rule_id` and `failure_reason`.
- `WARNING`: Logged and counted, but record stays GOOD.
