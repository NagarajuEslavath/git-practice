# WealthBridge Financial Data Platform — Architecture

## Overview
The **WealthBridge Financial Data Platform** is an enterprise-grade near-real-time financial data ingestion pipeline built on AWS serverless technologies.

```
Landing S3 Bucket (wealthbridge-landing)
    │
    ▼ (S3 ObjectCreated Event)
Preprocessor Lambda Function
    │  - Regex / Fuzzy filename parsing (TRANSACTION / POSITION)
    │  - Idempotent manifest registration (file_manifest table)
    │  - File completeness check per (batch_id, file_id)
    ▼ (boto3 start_job_run)
Glue ETL Ingestion Job (pyspark)
    ├── Loads DQ rules dynamically from dq_rule_registry (PostgreSQL)
    ├── Ingests CSV files into string-typed schema
    ├── Executes DQ Rule Engine (not_null, unique, allowed_values, expression)
    ├── Splits good/bad records with complete failure capture
    ├── Appends good/bad data to Iceberg tables (curated S3 bucket)
    └── Upserts run metadata, source files, failure counts, & operational summary
```

## Key System Contracts
1. **No Amazon Bedrock**: Operational summaries are generated deterministically in Python (`summary_generator.py`) and stored in `ingestion_run.summary`.
2. **Processing Unit**: Exactly one `TRANSACTION` file + one `POSITION` file per `file_id`.
3. **Configuration Driven**: Rules live in `dq_rule_registry`; adding a rule requires no code modifications.
4. **Curated Iceberg Storage**: 4 target tables partitioned by `batch_id`:
   - `transaction_good`
   - `transaction_bad`
   - `position_good`
   - `position_bad`
