"""AWS Connection verification script using boto3 and .env credentials."""
from __future__ import annotations

import sys
from pathlib import Path

# Load .env credentials if dotenv is present
try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).resolve().parent.parent / ".env")
except ImportError:
    pass

import boto3
from botocore.exceptions import BotoCoreError, ClientError


def verify_connection():
    print("Testing AWS Connection...")
    try:
        sts = boto3.client("sts")
        identity = sts.get_caller_identity()
        print("\n[SUCCESS] Connected to AWS!")
        print(f"  Account ID : {identity.get('Account')}")
        print(f"  Identity   : {identity.get('Arn')}")
        print(f"  UserId     : {identity.get('UserId')}")

        print("\nListing S3 Buckets in ap-south-1...")
        s3 = boto3.client("s3", region_name="ap-south-1")
        buckets = [b["Name"] for b in s3.list_buckets().get("Buckets", [])]
        print(f"  Found {len(buckets)} buckets:")
        for name in buckets:
            if "wealthbridge" in name:
                print(f"    - {name} [MATCH]")
            else:
                print(f"    - {name}")

    except (BotoCoreError, ClientError) as err:
        print("\n[ERROR] Failed to connect to AWS:")
        print(f"  {err}")
        print("\nPlease make sure that your .env file exists and contains valid AWS temporary credentials.")
        sys.exit(1)


if __name__ == "__main__":
    verify_connection()
