"""Python script to initialize the RDS PostgreSQL Database by executing SQL scripts."""
from __future__ import annotations

import os
import sys
from pathlib import Path

# Load .env
try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).resolve().parent.parent / ".env")
except ImportError:
    pass

import psycopg2


def get_password() -> str:
    password = os.getenv("DB_PASSWORD") or os.getenv("RDS_PASSWORD")
    if not password:
        password = input("Please enter the password for PostgreSQL RDS (user capvolt): ").strip()
    return password


def initialize():
    sql_dir = Path(__file__).resolve().parent.parent / "sql"
    if not sql_dir.exists():
        print(f"[ERROR] sql/ directory not found at {sql_dir}")
        sys.exit(1)

    host = "wealthbridgemetadatards.cpckkgcwoy32.ap-south-1.rds.amazonaws.com"
    port = 5432
    dbname = "WealthBridgeMetadataDatabase"
    user = "capvolt"
    password = get_password()

    if not password:
        print("[ERROR] Password is required to connect to RDS.")
        sys.exit(1)

    # SQL files to run in exact order (dropping old schemas first)
    sql_files = [
        "99_drop_all.sql",
        "00_common.sql",
        "01_create_ingestion_run.sql",
        "02_create_file_manifest.sql",
        "03_create_source_file.sql",
        "04_create_dq_rule_registry.sql",
        "05_create_dq_rule_failure_summary.sql",
        "06_seed_dq_rules.sql",
    ]


    print(f"Connecting to database '{dbname}' on '{host}' as user '{user}'...")
    try:
        conn = psycopg2.connect(
            host=host,
            port=port,
            dbname=dbname,
            user=user,
            password=password,
            connect_timeout=10,
        )
        conn.autocommit = True
        print("[SUCCESS] Connected to database.")
    except Exception as err:
        print(f"[ERROR] Database connection failed: {err}")
        sys.exit(1)

    with conn.cursor() as cur:
        for sql_file in sql_files:
            file_path = sql_dir / sql_file
            if not file_path.exists():
                print(f"[WARNING] SQL file {sql_file} not found. Skipping.")
                continue

            print(f"Executing script: {sql_file}...")
            content = file_path.read_text(encoding="utf-8")
            try:
                # Execute file content
                cur.execute(content)
                print(f"  Successfully executed {sql_file}.")
            except Exception as err:
                print(f"  [ERROR] Failed to execute {sql_file}: {err}")
                print("Rolling back database state and exiting.")
                conn.close()
                sys.exit(1)

    conn.close()
    print("\n[SUCCESS] RDS Database initialized successfully with all schemas and seed rules!")


if __name__ == "__main__":
    initialize()
