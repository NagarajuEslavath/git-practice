"""
Generate realistic CapVault sample files and validate them against the seeded
DQ rules by emulating the rule engine in plain Python (pandas). This proves,
before Spark ever runs, that every GOOD row is clean and every BAD row trips
exactly the rule(s) it was authored to trip.

Files written:
    batch1_1234_transcation12.csv   (transactions)
    batch1_1234_position21.csv      (positions)
"""
from __future__ import annotations

import csv
import datetime as dt
from pathlib import Path

HERE = Path(__file__).parent
ALLOWED_CCY = {"USD", "EUR", "GBP", "INR", "JPY", "AUD", "CAD", "CHF", "SGD", "HKD"}
ALLOWED_TXN_TYPE = {"BUY", "SELL", "DIVIDEND", "TRANSFER"}
TODAY = dt.date.today()
FUTURE = "2099-12-31"  # always in the future relative to any run

TXN_COLS = ["transaction_id", "account_id", "transaction_type", "trade_date",
            "settlement_date", "quantity", "price", "amount", "currency"]
POS_COLS = ["position_id", "account_id", "position_date", "quantity_held",
            "market_value", "currency"]

# Each row: (values..., intended_failures). intended_failures = [] means GOOD.
# ---------------------------------------------------------------------------
# TRANSACTIONS
# ---------------------------------------------------------------------------
transactions = [
    # --- clean, good records ---
    ("TXN0001", "CV1001", "BUY",      "2026-01-05", "2026-01-07", "100", "25.50", "2550.00", "USD", []),
    ("TXN0002", "CV1001", "SELL",     "2026-01-06", "2026-01-08", "50",  "42.10", "2105.00", "USD", []),
    ("TXN0003", "CV2002", "DIVIDEND", "2026-01-06", "2026-01-06", "10",  "1.00",  "10.00",   "EUR", []),
    ("TXN0004", "CV2002", "TRANSFER", "2026-01-07", "2026-01-09", "200", "10.00", "2000.00", "INR", []),
    ("TXN0005", "CV3003", "BUY",      "2026-01-08", "2026-01-10", "75",  "88.20", "6615.00", "GBP", []),
    ("TXN0006", "CV3003", "SELL",     "2026-01-09", "2026-01-12", "120", "15.75", "1890.00", "JPY", []),
    ("TXN0007", "CV4004", "BUY",      "2026-01-10", "2026-01-12", "30",  "300.00","9000.00", "USD", []),
    ("TXN0008", "CV4004", "DIVIDEND", "2026-01-10", "2026-01-11", "5",   "2.50",  "12.50",   "SGD", []),
    ("TXN0009", "CV5005", "SELL",     "2026-01-11", "2026-01-13", "60",  "45.00", "2700.00", "HKD", []),
    ("TXN0010", "CV5005", "TRANSFER", "2026-01-12", "2026-01-14", "90",  "12.00", "1080.00", "CHF", []),
    ("TXN0011", "CV6006", "BUY",      "2026-01-12", "2026-01-14", "40",  "55.25", "2210.00", "AUD", []),
    ("TXN0012", "CV6006", "SELL",     "2026-01-13", "2026-01-15", "80",  "33.00", "2640.00", "CAD", []),
    # --- bad records, one failure class each ---
    ("",        "CV7007", "BUY",      "2026-01-05", "2026-01-07", "100", "25.00", "2500.00", "USD", ["TXN_TRANSACTION_ID_NOT_NULL"]),
    ("TXN0013", "CV7008", "SELL",     "2026-01-05", "2026-01-07", "10",  "5.00",  "50.00",   "USD", ["TXN_TRANSACTION_ID_UNIQUE"]),   # duplicate pair (a)
    ("TXN0013", "CV7009", "BUY",      "2026-01-05", "2026-01-07", "20",  "6.00",  "120.00",  "USD", ["TXN_TRANSACTION_ID_UNIQUE"]),   # duplicate pair (b)
    ("TXN0014", "ZZ9999", "BUY",      "2026-01-05", "2026-01-07", "100", "25.00", "2500.00", "USD", ["TXN_ACCOUNT_ID_PREFIX"]),
    ("TXN0015", "CV8008", "SHORT",    "2026-01-05", "2026-01-07", "100", "25.00", "2500.00", "USD", ["TXN_TYPE_ALLOWED"]),
    ("TXN0016", "CV8009", "BUY",      "2026-01-15", "2026-01-10", "100", "25.00", "2500.00", "USD", ["TXN_TRADE_LE_SETTLEMENT"]),
    ("TXN0017", "CV8010", "BUY",      "2026-01-05", "2026-01-07", "0",   "25.00", "2500.00", "USD", ["TXN_QUANTITY_POSITIVE"]),
    ("TXN0018", "CV8011", "BUY",      "2026-01-05", "2026-01-07", "100", "-3.00", "2500.00", "USD", ["TXN_PRICE_POSITIVE"]),
    ("TXN0019", "CV8012", "BUY",      "2026-01-05", "2026-01-07", "100", "25.00", "0.00",    "USD", ["TXN_AMOUNT_POSITIVE"]),
    ("TXN0020", "CV8013", "BUY",      "2026-01-05", "2026-01-07", "100", "25.00", "2500.00", "XYZ", ["TXN_CURRENCY_ALLOWED"]),
    ("TXN0021", "CV8014", "BUY",      "2026-01-05", "2026-01-07", "100", "25.00", "2500.00", "",    ["TXN_CURRENCY_ALLOWED"]),        # missing currency
    # --- multi-failure record: non-CV account + negative amount + bad currency ---
    ("TXN0022", "AB1234", "BUY",      "2026-01-05", "2026-01-07", "100", "25.00", "-500.00", "ABC",
        ["TXN_ACCOUNT_ID_PREFIX", "TXN_AMOUNT_POSITIVE", "TXN_CURRENCY_ALLOWED"]),
]

# ---------------------------------------------------------------------------
# POSITIONS
# ---------------------------------------------------------------------------
positions = [
    # --- clean, good records ---
    ("POS0001", "CV1001", "2026-01-15", "100",  "12500.00", "USD", []),
    ("POS0002", "CV1001", "2026-01-15", "50",   "3200.00",  "USD", []),
    ("POS0003", "CV2002", "2026-01-15", "0",    "0.00",     "EUR", []),   # zero holdings, still valid
    ("POS0004", "CV2002", "2026-01-15", "200",  "45000.00", "INR", []),
    ("POS0005", "CV3003", "2026-01-15", "75",   "8800.00",  "GBP", []),
    ("POS0006", "CV3003", "2026-01-15", "120",  "1500.00",  "JPY", []),
    ("POS0007", "CV4004", "2026-01-15", "30",   "9000.00",  "USD", []),
    ("POS0008", "CV5005", "2026-01-15", "60",   "2700.00",  "HKD", []),
    ("POS0009", "CV6006", "2026-01-15", "40",   "2210.00",  "AUD", []),
    ("POS0010", "CV6006", "2026-01-15", "80",   "2640.00",  "CAD", []),
    # --- bad records, one failure class each ---
    ("",        "CV7007", "2026-01-15", "10",   "500.00",   "USD", ["POS_POSITION_ID_NOT_NULL"]),
    ("POS0011", "CV7008", "2026-01-15", "5",    "250.00",   "USD", ["POS_POSITION_ID_UNIQUE"]),   # duplicate pair (a)
    ("POS0011", "CV7009", "2026-01-15", "8",    "400.00",   "USD", ["POS_POSITION_ID_UNIQUE"]),   # duplicate pair (b)
    ("POS0012", "ZZ0000", "2026-01-15", "10",   "500.00",   "USD", ["POS_ACCOUNT_ID_PREFIX"]),
    ("POS0013", "CV8008", FUTURE,       "10",   "500.00",   "USD", ["POS_DATE_NOT_FUTURE"]),
    ("POS0014", "CV8009", "2026-01-15", "-5",   "500.00",   "USD", ["POS_QUANTITY_NONNEG"]),
    ("POS0015", "CV8010", "2026-01-15", "10",   "-100.00",  "USD", ["POS_MARKET_VALUE_NONNEG"]),
    ("POS0016", "CV8011", "2026-01-15", "10",   "500.00",   "XYZ", ["POS_CURRENCY_ALLOWED"]),
    # --- multi-failure record: non-CV account + negative market value + future date ---
    ("POS0017", "QQ7777", FUTURE,       "10",   "-999.00",  "USD",
        ["POS_ACCOUNT_ID_PREFIX", "POS_DATE_NOT_FUTURE", "POS_MARKET_VALUE_NONNEG"]),
]


def _to_date(v):
    try:
        return dt.date.fromisoformat(v) if v else None
    except ValueError:
        return None


def _to_num(v):
    try:
        return float(v) if v not in (None, "") else None
    except ValueError:
        return None


def evaluate_transactions(rows):
    ids = [r[0] for r in rows if r[0] != ""]
    dup_ids = {i for i in ids if ids.count(i) > 1}
    results = []
    for r in rows:
        tid, acct, ttype, trade, settle, qty, price, amt, ccy = r[:9]
        fails = []
        if tid == "":
            fails.append("TXN_TRANSACTION_ID_NOT_NULL")
        if tid in dup_ids:
            fails.append("TXN_TRANSACTION_ID_UNIQUE")
        if not acct.startswith("CV"):
            fails.append("TXN_ACCOUNT_ID_PREFIX")
        if ttype not in ALLOWED_TXN_TYPE:
            fails.append("TXN_TYPE_ALLOWED")
        td, sd = _to_date(trade), _to_date(settle)
        if td is None or sd is None or not (td <= sd):
            fails.append("TXN_TRADE_LE_SETTLEMENT")
        q, p, a = _to_num(qty), _to_num(price), _to_num(amt)
        if q is None or not (q > 0):
            fails.append("TXN_QUANTITY_POSITIVE")
        if p is None or not (p > 0):
            fails.append("TXN_PRICE_POSITIVE")
        if a is None or not (a > 0):
            fails.append("TXN_AMOUNT_POSITIVE")
        if ccy not in ALLOWED_CCY:
            fails.append("TXN_CURRENCY_ALLOWED")
        results.append(fails)
    return results


def evaluate_positions(rows):
    ids = [r[0] for r in rows if r[0] != ""]
    dup_ids = {i for i in ids if ids.count(i) > 1}
    results = []
    for r in rows:
        pid, acct, pdate, qh, mv, ccy = r[:6]
        fails = []
        if pid == "":
            fails.append("POS_POSITION_ID_NOT_NULL")
        if pid in dup_ids:
            fails.append("POS_POSITION_ID_UNIQUE")
        if not acct.startswith("CV"):
            fails.append("POS_ACCOUNT_ID_PREFIX")
        d = _to_date(pdate)
        if d is None or not (d <= TODAY):
            fails.append("POS_DATE_NOT_FUTURE")
        q, m = _to_num(qh), _to_num(mv)
        if q is None or not (q >= 0):
            fails.append("POS_QUANTITY_NONNEG")
        if m is None or not (m >= 0):
            fails.append("POS_MARKET_VALUE_NONNEG")
        if ccy not in ALLOWED_CCY:
            fails.append("POS_CURRENCY_ALLOWED")
        results.append(fails)
    return results


def write_csv(path, header, rows):
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        for r in rows:
            w.writerow(r[:len(header)])


def validate(name, rows, results):
    ok = True
    for idx, (row, actual) in enumerate(zip(rows, results)):
        intended = set(row[-1])
        actual_set = set(actual)
        if intended != actual_set:
            ok = False
            print(f"  [MISMATCH] {name} row {idx} id={row[0]!r}: "
                  f"intended={sorted(intended)} actual={sorted(actual_set)}")
    good = sum(1 for a in results if not a)
    bad = sum(1 for a in results if a)
    print(f"  {name}: {len(rows)} rows -> {good} good, {bad} bad  "
          f"[{'PASS' if ok else 'FAIL'}]")
    return ok, good, bad


def main():
    write_csv(HERE / "batch1_1234_transcation12.csv", TXN_COLS, transactions)
    write_csv(HERE / "batch1_1234_position21.csv", POS_COLS, positions)

    print("Validating sample data against seeded DQ rules (emulated engine):")
    t_res = evaluate_transactions(transactions)
    p_res = evaluate_positions(positions)
    t_ok, tg, tb = validate("transactions", transactions, t_res)
    p_ok, pg, pb = validate("positions", positions, p_res)

    total = (tg + tb) + (pg + pb)
    good = tg + pg
    score = round(good / total * 100, 2)
    print(f"\nCombined: {total} records, {good} good, {total - good} bad, "
          f"DQ score = {score}%")
    print("RESULT:", "ALL EXPECTATIONS MATCHED" if (t_ok and p_ok) else "MISMATCH FOUND")
    return 0 if (t_ok and p_ok) else 1


if __name__ == "__main__":
    raise SystemExit(main())
