"""Main Glue job orchestration script for WealthBridge Financial Data Platform."""
from __future__ import annotations

import sys
import time
from typing import Any, Dict, List, Tuple

from pyspark.sql import SparkSession

from glue.config import load_config
from glue.dq_engine import apply_rules, calculate_dq_score
from glue.iceberg_writer import write_bad, write_good
from glue.logger import get_logger
from glue.metadata_writer import (
    record_ingestion_run_start,
    record_rule_failure_summary,
    record_source_file,
    update_ingestion_run_finish,
)
from glue.reader import read_entity_csv, resolve_batch_files, discover_batch_files
from glue.rule_loader import load_active_rules
from glue.summary_generator import build_summary
from glue.utils import new_run_id, read_job_args, tag_s3_object


def get_spark_session(app_name: str = "WealthBridgeIngestionJob") -> Any:
    """Creates or gets active SparkSession, returning None if Spark runtime is unavailable locally."""
    try:
        spark = (
            SparkSession.builder.appName(app_name)
            .master("local[*]")
            .getOrCreate()
        )
        spark.sparkContext.setLogLevel("WARN")
        return spark
    except Exception as err:
        print(f"[spark_init_info] Local PySpark session unavailable ({err}). Falling back to local engine.")
        return None


def run_pipeline(job_args: Dict[str, str], db_conn: Any = None) -> int:
    start_ts = time.time()
    batch_id = job_args.get("batch_id", "batch1")
    file_id = job_args.get("file_id", "").strip()
    env = job_args.get("env", "dev")

    logger = get_logger("glue_main", batch_id=batch_id, file_id=file_id)

    cfg = load_config(env=env)
    spark = get_spark_session(cfg.glue.job_name)

    # Determine files to process
    if file_id:
        # Process specific file_id
        discovered = {file_id: resolve_batch_files(batch_id, file_id, base_dir_or_bucket="sample_data")}
    else:
        # Auto-discover all files for this batch_id
        logger.info(f"No file_id provided. Auto-discovering files for batch_id={batch_id}...", extra={"stage": "DISCOVER"})
        discovered = discover_batch_files(batch_id, base_dir_or_bucket="sample_data")
        if not discovered:
            logger.error(f"No files discovered for batch_id={batch_id}", extra={"stage": "DISCOVER"})
            return 1
        logger.info(f"Discovered {len(discovered)} file pairs to process: {list(discovered.keys())}", extra={"stage": "DISCOVER"})

    total_good_all = 0
    total_bad_all = 0
    total_records_all = 0
    combined_failures: Dict[str, int] = {}
    all_bad_records: List[Dict[str, Any]] = []
    overall_statuses: List[str] = []

    # Process each discovered file_id
    for f_id, resolved_files in discovered.items():
        run_id = new_run_id(batch_id, f_id)
        run_logger = get_logger("glue_main", run_id=run_id, batch_id=batch_id, file_id=f_id)
        run_logger.info(f"Processing sub-run batch_id={batch_id}, file_id={f_id}", extra={"stage": "SUB_INIT"})

        # Record start in metadata database
        record_ingestion_run_start(db_conn, run_id, batch_id, f_id)

        entities = ["TRANSACTION", "POSITION"]
        entity_results: Dict[str, Any] = {}
        sub_good_count = 0
        sub_bad_count = 0
        sub_total_count = 0
        sub_failures: Dict[str, int] = {}

        for entity in entities:
            try:
                file_path = resolved_files.get(entity)
                if not file_path:
                    run_logger.warning(f"No source file found for entity={entity}", extra={"stage": f"READ_{entity}"})
                    entity_results[entity] = {"status": "MISSING", "good": 0, "bad": 0, "total": 0}
                    continue

                rules = load_active_rules(conn=db_conn, entity_type=entity)
                df = read_entity_csv(spark, file_path)
                raw_count = df.count()

                # Execute DQ Rule Engine
                good_recs, bad_recs, fail_counts = apply_rules(df, rules)
                g_cnt, b_cnt = len(good_recs), len(bad_recs)
                t_cnt = g_cnt + b_cnt

                sub_good_count += g_cnt
                sub_bad_count += b_cnt
                sub_total_count += t_cnt

                all_bad_records.extend(bad_recs)

                # Aggregate failures
                for r_id, cnt in fail_counts.items():
                    sub_failures[r_id] = sub_failures.get(r_id, 0) + cnt
                    combined_failures[r_id] = combined_failures.get(r_id, 0) + cnt

                file_name = file_path.split("/")[-1].split("\\")[-1]
                run_ctx = {
                    "run_id": run_id,
                    "batch_id": batch_id,
                    "file_id": f_id,
                    "source_file": file_name,
                }

                # Write data
                write_good(spark, good_recs, entity, run_ctx, catalog_db=cfg.glue.iceberg_db)
                write_bad(spark, bad_recs, entity, run_ctx, catalog_db=cfg.glue.iceberg_db)

                # Record metadata
                record_source_file(
                    db_conn, run_id, file_name, entity, file_path, batch_id, f_id, t_cnt, g_cnt, b_cnt, "PROCESSED"
                )
                record_rule_failure_summary(db_conn, run_id, batch_id, f_id, entity, fail_counts)

                # Tag S3 Object
                tag_s3_object(cfg.s3.landing_bucket, file_name, "Completed", region_name=cfg.aws.region)

                entity_results[entity] = {"status": "SUCCESS", "good": g_cnt, "bad": b_cnt, "total": t_cnt}

            except Exception as err:
                run_logger.error(f"Error processing entity={entity}: {err}", extra={"stage": f"ERROR_{entity}"}, exc_info=True)
                entity_results[entity] = {"status": "FAILED", "error": str(err)}

        # Determine sub-run status
        statuses = [res["status"] for res in entity_results.values()]
        if all(s == "SUCCESS" for s in statuses):
            sub_status = "COMPLETED"
        elif any(s == "SUCCESS" for s in statuses):
            sub_status = "PARTIAL"
        else:
            sub_status = "FAILED"

        overall_statuses.append(sub_status)
        total_good_all += sub_good_count
        total_bad_all += sub_bad_count
        total_records_all += sub_total_count

        sub_duration = round(time.time() - start_ts, 2)
        sub_dq_score = calculate_dq_score(sub_good_count, sub_total_count)

        sub_top_failures = sorted(
            [(r_id, cnt) for r_id, cnt in sub_failures.items() if cnt > 0],
            key=lambda x: x[1],
            reverse=True,
        )

        sub_run_ctx = {
            "run_id": run_id,
            "batch_id": batch_id,
            "file_id": f_id,
            "status": sub_status,
            "duration_seconds": sub_duration,
        }
        sub_stats = {
            "total_records": sub_total_count,
            "good_records": sub_good_count,
            "bad_records": sub_bad_count,
            "dq_score": sub_dq_score,
        }

        sub_summary = build_summary(sub_run_ctx, sub_stats, sub_top_failures)
        run_logger.info(f"Sub-run Complete: {sub_summary}", extra={"stage": "SUB_COMPLETE"})

        # Update run metadata in store
        update_ingestion_run_finish(
            db_conn,
            run_id=run_id,
            duration_seconds=sub_duration,
            total_records=sub_total_count,
            good_records=sub_good_count,
            bad_records=sub_bad_count,
            dq_score=sub_dq_score,
            status=sub_status,
            summary=sub_summary,
        )

    # Combined status determination
    if all(s == "COMPLETED" for s in overall_statuses):
        final_status = "COMPLETED"
    elif any(s in ("COMPLETED", "PARTIAL") for s in overall_statuses):
        final_status = "PARTIAL"
    else:
        final_status = "FAILED"

    total_duration = round(time.time() - start_ts, 2)
    final_dq_score = calculate_dq_score(total_good_all, total_records_all)

    # Consolidated report summary
    consolidated_top_failures = sorted(
        [(r_id, cnt) for r_id, cnt in combined_failures.items() if cnt > 0],
        key=lambda x: x[1],
        reverse=True,
    )

    consolidated_run_ctx = {
        "run_id": f"CONSOLIDATED_{batch_id}_{int(start_ts)}",
        "batch_id": batch_id,
        "file_id": "ALL_DISCOVERED",
        "status": final_status,
        "duration_seconds": total_duration,
    }
    consolidated_stats = {
        "total_records": total_records_all,
        "good_records": total_good_all,
        "bad_records": total_bad_all,
        "dq_score": final_dq_score,
    }

    try:
        from pathlib import Path
        from glue.summary_generator import generate_html_report
        
        reports_dir = Path("reports")
        reports_dir.mkdir(exist_ok=True)
        
        f_suffix = file_id if file_id else "all"
        report_filename = f"ingestion_report_{batch_id}_{f_suffix}.html"
        report_path = reports_dir / report_filename
        
        # Write unique batch report
        generate_html_report(
            consolidated_run_ctx, consolidated_stats, consolidated_top_failures, all_bad_records, str(report_path)
        )
        
        # Write latest_report.html
        latest_path = reports_dir / "latest_report.html"
        generate_html_report(
            consolidated_run_ctx, consolidated_stats, consolidated_top_failures, all_bad_records, str(latest_path)
        )
        
        # Clean up old root file if it exists
        old_root_file = Path("ingestion_report.html")
        if old_root_file.exists():
            old_root_file.unlink()
            
    except Exception as err:
        logger.error(f"Failed to generate consolidated HTML report in reports/ folder: {err}", extra={"stage": "REPORT_ERROR"})

    logger.info(f"Batch Processing Complete. Combined Status: {final_status}, Combined DQ Score: {final_dq_score}%", extra={"stage": "BATCH_COMPLETE"})
    return 0 if final_status in ("COMPLETED", "PARTIAL") else 1


def main() -> None:
    args = read_job_args()
    exit_code = run_pipeline(args)
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
