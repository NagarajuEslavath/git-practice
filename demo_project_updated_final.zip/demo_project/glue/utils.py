"""Utility functions for Glue ETL pipeline: filename parsing, S3 tagging, run IDs, and argument parsing."""
from __future__ import annotations

import argparse
import datetime as dt
import re
import sys
import uuid
from typing import NamedTuple, Optional

import boto3
from botocore.exceptions import BotoCoreError, ClientError


class ParsedFile(NamedTuple):
    batch_id: str
    file_id: str
    entity_type: str


def parse_filename(key: str) -> Optional[ParsedFile]:
    """
    Parses S3 key / filename into (batch_id, file_id, entity_type).

    Rule §3.6:
    Filename format: batch{N}_{fileid}_{name}.csv, e.g. batch1_1234_transcation12.csv.
    Entity is fuzzy-matched from token 3 (trans* -> TRANSACTION, posit* -> POSITION;
    handles 'transcation' misspelling and trailing digits).
    Unmatched -> returns None.
    """
    filename = key.split("/")[-1]
    if not filename.endswith(".csv"):
        return None

    stem = filename[:-4]
    parts = stem.split("_")
    if len(parts) < 3:
        return None

    batch_id = parts[0]
    file_id = parts[1]
    rest = "_".join(parts[2:]).lower()

    if re.match(r"^trans.*", rest):
        entity_type = "TRANSACTION"
    elif re.match(r"^posit.*", rest):
        entity_type = "POSITION"
    else:
        return None

    return ParsedFile(batch_id=batch_id, file_id=file_id, entity_type=entity_type)


def new_run_id(batch_id: str, file_id: str) -> str:
    """Generates a unique run ID for an ingestion execution."""
    ts = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d_%H%M%S")
    short_uid = str(uuid.uuid4())[:8]
    return f"RUN_{batch_id}_{file_id}_{ts}_{short_uid}"


def tag_s3_object(bucket: str, key: str, status: str, region_name: str = "ap-south-1") -> bool:
    """
    Tags an S3 object with ProcessStatus=<status>.
    Returns True if successful, False if S3 call fails (e.g. in local test mode).
    """
    try:
        s3_client = boto3.client("s3", region_name=region_name)
        s3_client.put_object_tagging(
            Bucket=bucket,
            Key=key,
            Tagging={"TagSet": [{"Key": "ProcessStatus", "Value": status}]},
        )
        return True
    except (BotoCoreError, ClientError, Exception) as err:
        # In local/test mode without AWS credentials, log warning gracefully
        print(f"[s3_tagging_warning] Could not tag S3 object s3://{bucket}/{key}: {err}")
        return False


def read_job_args() -> dict[str, str]:
    """
    Reads job arguments. Supports AWS Glue getResolvedOptions when in Glue environment,
    or argparse CLI flags when executed locally.
    """
    # Check if running inside AWS Glue environment
    if "awsglue.utils" in sys.modules or "--JOB_NAME" in sys.argv:
        try:
            from awsglue.utils import getResolvedOptions
            options = getResolvedOptions(
                sys.argv,
                ["JOB_NAME", "batch_id", "file_id", "env"],
            )
            return options
        except Exception:
            pass

    # CLI fallback for local development & verification
    parser = argparse.ArgumentParser(description="WealthBridge Glue Ingestion Job")
    parser.add_argument("--JOB_NAME", default="wealthbridge-ingestion-job", help="Glue job name")
    parser.add_argument("--batch_id", default="batch1", help="Batch ID")
    parser.add_argument("--file_id", default="", help="File ID (optional, auto-discovers if omitted)")

    parser.add_argument("--env", default="dev", help="Environment (dev/prod)")
    args, _ = parser.parse_known_args()

    return {
        "JOB_NAME": args.JOB_NAME,
        "batch_id": args.batch_id,
        "file_id": args.file_id,
        "env": args.env,
    }
