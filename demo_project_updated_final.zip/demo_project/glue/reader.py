"""CSV reader module for ingestion pipeline using PySpark."""
from __future__ import annotations

import os
from pathlib import Path
from typing import Dict

from pyspark.sql import DataFrame, SparkSession
from glue.utils import parse_filename


class LocalDataFrameWrapper:
    """Wrapper around pandas DataFrame to mirror Spark DataFrame inspection methods."""

    def __init__(self, df):
        self._df = df
        self.columns = list(df.columns)

    def count(self) -> int:
        return len(self._df)

    @property
    def schema(self):
        class Field:
            def __init__(self, name):
                self.name = name
                self.dataType = type("DataType", (), {"simpleString": lambda: "string"})()

        class Schema:
            def __init__(self, names):
                self.names = names
                self.fields = [Field(n) for n in names]

        return Schema(self.columns)


def read_entity_csv(spark, file_path: str):
    """
    Reads a CSV file into a DataFrame with all columns inferred as strings.

    Per §3.7: Infer columns from the CSV header, treating initial read values as strings.
    If PySpark session is available, uses PySpark. Otherwise falls back to pandas.
    """
    if spark is not None:
        try:
            return (
                spark.read.option("header", "true")
                .option("inferSchema", "false")
                .csv(file_path)
            )
        except Exception:
            pass

    # Pandas local fallback
    import pandas as pd
    df = pd.read_csv(file_path, dtype=str, keep_default_na=False).fillna("")
    return LocalDataFrameWrapper(df)




def discover_batch_files(
    batch_id: str,
    base_dir_or_bucket: str = "sample_data",
) -> Dict[str, Dict[str, str]]:
    """
    Scans the base directory or bucket for all CSV files matching the batch_id,
    and groups them by file_id.

    Returns:
        Dict mapping file_id -> {"TRANSACTION": path, "POSITION": path}
    """
    grouped: Dict[str, Dict[str, str]] = {}

    if base_dir_or_bucket.startswith("s3://") or base_dir_or_bucket.startswith("s3a://"):
        # For S3, we would list objects with prefix batch_id and parse them.
        # Fallback empty for local discovery testing.
        return grouped

    search_dir = Path(base_dir_or_bucket)
    if not search_dir.exists():
        search_dir = Path(".")

    for file_item in search_dir.glob("*.csv"):
        parsed = parse_filename(file_item.name)
        if parsed and parsed.batch_id == batch_id:
            f_id = parsed.file_id
            if f_id not in grouped:
                grouped[f_id] = {}
            grouped[f_id][parsed.entity_type] = str(file_item.resolve())

    return grouped


def resolve_batch_files(

    batch_id: str,
    file_id: str,
    base_dir_or_bucket: str = "sample_data",
) -> Dict[str, str]:
    """
    Resolves source file paths for TRANSACTION and POSITION entities matching batch_id & file_id.

    Returns a dict mapping entity_type ("TRANSACTION", "POSITION") -> file path / S3 URI.
    """
    resolved: Dict[str, str] = {}

    if base_dir_or_bucket.startswith("s3://") or base_dir_or_bucket.startswith("s3a://"):
        # S3 path convention
        prefix = base_dir_or_bucket.rstrip("/")
        # Standard naming scheme search
        resolved["TRANSACTION"] = f"{prefix}/{batch_id}_{file_id}_transcation12.csv"
        resolved["POSITION"] = f"{prefix}/{batch_id}_{file_id}_position21.csv"
        return resolved

    # Local file directory search
    search_dir = Path(base_dir_or_bucket)
    if not search_dir.exists():
        search_dir = Path(".")

    for file_item in search_dir.glob("*.csv"):
        parsed = parse_filename(file_item.name)
        if parsed and parsed.batch_id == batch_id and parsed.file_id == file_id:
            resolved[parsed.entity_type] = str(file_item.resolve())

    return resolved
