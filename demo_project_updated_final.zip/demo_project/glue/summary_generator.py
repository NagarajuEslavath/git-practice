"""Deterministic AI-like Summary and Dashboard Generator with Correction Recommendations."""
from __future__ import annotations

import datetime as dt
from pathlib import Path
from typing import Any, Dict, List, Tuple

# Recommendation mapping for all 16 DQ rules
RECOMMENDATIONS = {
    "TXN_TRANSACTION_ID_NOT_NULL": "Add a valid transaction identifier. Blank primary keys are strictly rejected.",
    "TXN_TRANSACTION_ID_UNIQUE": "Deduplicate this ID. Uniqueness check rejects all copies of duplicated transaction IDs.",
    "TXN_ACCOUNT_ID_PREFIX": "Correct the account prefix. Account ID must start with the standard 'CV' prefix.",
    "TXN_TYPE_ALLOWED": "Change transaction type to an approved value: BUY, SELL, DIVIDEND, or TRANSFER.",
    "TXN_TRADE_LE_SETTLEMENT": "Adjust dates so trade_date is chronological (on or before settlement_date).",
    "TXN_QUANTITY_POSITIVE": "Correct quantity. Transactions must have a positive quantity (> 0).",
    "TXN_PRICE_POSITIVE": "Correct price. Transactions must have a positive price (> 0).",
    "TXN_AMOUNT_POSITIVE": "Correct amount. Transactions must have a positive amount (> 0).",
    "TXN_CURRENCY_ALLOWED": "Update currency code to a supported ISO standard: USD, EUR, GBP, INR, JPY, AUD, CAD, CHF, SGD, HKD.",
    "POS_POSITION_ID_NOT_NULL": "Add a valid position identifier. Blank primary keys are strictly rejected.",
    "POS_POSITION_ID_UNIQUE": "Deduplicate this ID. Uniqueness check rejects all copies of duplicated position IDs.",
    "POS_ACCOUNT_ID_PREFIX": "Correct the account prefix. Account ID must start with the standard 'CV' prefix.",
    "POS_DATE_NOT_FUTURE": "Adjust position date. Futures dates are not accepted (must be <= today).",
    "POS_QUANTITY_NONNEG": "Correct quantity. Position quantity held must be non-negative (>= 0).",
    "POS_MARKET_VALUE_NONNEG": "Correct market value. Position market value must be non-negative (>= 0).",
    "POS_CURRENCY_ALLOWED": "Update currency code to a supported ISO standard: USD, EUR, GBP, INR, JPY, AUD, CAD, CHF, SGD, HKD.",
}


def get_recommendations_for_rules(failed_rules_str: str) -> List[str]:
    """Resolves specific correction recommendations for a comma-separated string of failed rule IDs."""
    if not failed_rules_str:
        return []
    rules = [r.strip() for r in failed_rules_str.split(",")]
    return [RECOMMENDATIONS.get(rule, f"Check rule {rule} criteria.") for rule in rules]


def build_summary(
    run_ctx: Dict[str, Any],
    stats: Dict[str, Any],
    top_failures: List[Tuple[str, int]] | None = None,
) -> str:
    """Produces the standard business-friendly operational summary paragraph."""
    run_id = run_ctx.get("run_id", "N/A")
    batch_id = run_ctx.get("batch_id", "N/A")
    file_id = run_ctx.get("file_id", "N/A")
    status = run_ctx.get("status", "SUCCESS")
    duration = run_ctx.get("duration_seconds", 0.0)

    total = stats.get("total_records", 0)
    good = stats.get("good_records", 0)
    bad = stats.get("bad_records", 0)
    dq_score = stats.get("dq_score", 100.0)

    summary_lines = [
        f"WealthBridge Ingestion Run [{run_id}] completed for batch '{batch_id}' (File ID: {file_id}) with status '{status}' in {duration:.2f}s.",
        f"Processed {total} total records: {good} GOOD, {bad} BAD. Combined Data Quality Score: {dq_score:.2f}%.",
    ]

    if top_failures:
        failure_str = ", ".join([f"{rule_id} ({count} failures)" for rule_id, count in top_failures if count > 0])
        if failure_str:
            summary_lines.append(f"Top Rule Failures: {failure_str}.")
        else:
            summary_lines.append("No rule failures recorded.")
    else:
        summary_lines.append("No rule failures recorded.")

    return " ".join(summary_lines)


def build_ai_summary(
    stats: Dict[str, Any],
    top_failures: List[Tuple[str, int]],
) -> str:
    """Generates an advanced analytical summary outlining data health findings and suggestions."""
    dq_score = stats.get("dq_score", 100.0)
    bad = stats.get("bad_records", 0)

    if bad == 0:
        return (
            "AI Insights: Outstanding data run! 100% of ingestion records passed validation checks. "
            "System performance and source formatting are fully aligned with the CapVault ledger requirements."
        )

    # Summarize top rule failure
    top_rule, top_count = top_failures[0]
    total_failures = sum(count for _, count in top_failures)

    insights = [
        f"AI Analysis: Ingestion data health is at {dq_score:.1f}%. Out of {stats.get('total_records', 0)} records, "
        f"{bad} records failed critical checks, triggering {total_failures} total rules failures.",
        f"The primary driver is '{top_rule}' represents {((top_count/total_failures)*100):.1f}% of total rule failures.",
    ]

    # Generate actionable system recommendations
    recommendation_bullets = []
    for rule_id, _ in top_failures[:3]:
        recommendation_bullets.append(RECOMMENDATIONS.get(rule_id, "Verify rule schema configuration."))

    insights.append(f"Action Items to Correct: 1. {recommendation_bullets[0]} 2. Resolve duplicate keys matching uniqueness criteria.")

    return " ".join(insights)


def generate_html_report(
    run_ctx: Dict[str, Any],
    stats: Dict[str, Any],
    top_failures: List[Tuple[str, int]],
    bad_records_list: List[Dict[str, Any]],
    output_path: str = "ingestion_report.html",
):
    """Generates a premium, dynamic, modern dark mode HTML report dashboard with CSS Grid and visual elements."""
    run_id = run_ctx.get("run_id", "N/A")
    batch_id = run_ctx.get("batch_id", "N/A")
    file_id = run_ctx.get("file_id", "N/A")
    status = run_ctx.get("status", "SUCCESS")
    duration = run_ctx.get("duration_seconds", 0.0)

    total = stats.get("total_records", 0)
    good = stats.get("good_records", 0)
    bad = stats.get("bad_records", 0)
    dq_score = stats.get("dq_score", 100.0)

    ai_narrative = build_ai_summary(stats, top_failures)

    # Build Failure Rules rows
    rules_rows_html = ""
    for r_id, count in top_failures:
        rec_help = RECOMMENDATIONS.get(r_id, "Check column constraints.")
        rules_rows_html += f"""
        <tr>
            <td class="rule-code">{r_id}</td>
            <td class="rule-count">{count}</td>
            <td class="rule-rec">{rec_help}</td>
        </tr>
        """

    # Build Bad Records Correction table rows
    bad_records_html = ""
    for idx, r in enumerate(bad_records_list[:50]):  # Limit to top 50 for performance
        record_id = r.get("transaction_id") or r.get("position_id") or f"ROW_{idx}"
        entity_type = "TRANSACTION" if "transaction_id" in r else "POSITION"
        failed_rules = r.get("failed_rule_id", "Unknown")
        recs_list = get_recommendations_for_rules(failed_rules)
        recs_html = "<br/>".join([f"• {rec}" for rec in recs_list])

        bad_records_html += f"""
        <tr>
            <td><strong>{record_id}</strong></td>
            <td><span class="badge {entity_type.lower()}">{entity_type}</span></td>
            <td class="rule-code">{failed_rules}</td>
            <td class="rule-rec">{recs_html}</td>
        </tr>
        """

    if not bad_records_html:
        bad_records_html = """<tr><td colspan="4" class="no-failures">No bad records found! Ingestion was 100% clean.</td></tr>"""

    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WealthBridge Ingestion Report - Run {run_id}</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&family=Space+Grotesk:wght@500;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --bg-primary: #0a0b0d;
            --bg-secondary: #12141c;
            --bg-tertiary: #1a1d29;
            --accent-green: #00e676;
            --accent-red: #ff3d00;
            --accent-blue: #00b0ff;
            --text-main: #f0f2f5;
            --text-muted: #8b949e;
            --border-color: #262c40;
            --card-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.5);
        }}

        * {{
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }}

        body {{
            font-family: 'Outfit', sans-serif;
            background-color: var(--bg-primary);
            color: var(--text-main);
            line-height: 1.6;
            padding: 2.5rem;
        }}

        header {{
            margin-bottom: 2.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 1.5rem;
        }}

        .brand h1 {{
            font-family: 'Space Grotesk', sans-serif;
            font-weight: 800;
            font-size: 2.2rem;
            letter-spacing: -1px;
            background: linear-gradient(135deg, #00b0ff, #00e676);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }}

        .brand p {{
            color: var(--text-muted);
            font-size: 0.95rem;
        }}

        .status-pill {{
            padding: 0.6rem 1.2rem;
            border-radius: 50px;
            font-weight: 600;
            font-size: 0.9rem;
            letter-spacing: 1px;
            text-transform: uppercase;
        }}

        .status-pill.completed {{
            background: rgba(0, 230, 118, 0.15);
            color: var(--accent-green);
            border: 1px solid var(--accent-green);
        }}

        .status-pill.partial {{
            background: rgba(0, 176, 255, 0.15);
            color: var(--accent-blue);
            border: 1px solid var(--accent-blue);
        }}

        .status-pill.failed {{
            background: rgba(255, 61, 0, 0.15);
            color: var(--accent-red);
            border: 1px solid var(--accent-red);
        }}

        .metrics-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2.5rem;
        }}

        .card {{
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 1.8rem;
            box-shadow: var(--card-shadow);
            transition: transform 0.3s ease, border-color 0.3s ease;
        }}

        .card:hover {{
            transform: translateY(-5px);
            border-color: #3b4566;
        }}

        .card-title {{
            color: var(--text-muted);
            font-size: 0.85rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            margin-bottom: 0.5rem;
        }}

        .card-value {{
            font-size: 2.2rem;
            font-weight: 700;
            font-family: 'Space Grotesk', sans-serif;
        }}

        .card-value.green {{ color: var(--accent-green); }}
        .card-value.red {{ color: var(--accent-red); }}
        .card-value.blue {{ color: var(--accent-blue); }}

        .dashboard-layout {{
            display: grid;
            grid-template-columns: 1fr;
            gap: 2.5rem;
        }}

        @media (min-width: 1024px) {{
            .dashboard-layout {{
                grid-template-columns: 3fr 2fr;
            }}
        }}

        .section-title {{
            font-family: 'Space Grotesk', sans-serif;
            font-size: 1.4rem;
            font-weight: 700;
            margin-bottom: 1.2rem;
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }}

        .ai-box {{
            background: linear-gradient(145deg, #151824, #1a2233);
            border: 1px solid rgba(0, 176, 255, 0.3);
            border-radius: 16px;
            padding: 2rem;
            margin-bottom: 2.5rem;
            box-shadow: var(--card-shadow);
            position: relative;
            overflow: hidden;
        }}

        .ai-box::before {{
            content: 'AI ANALYST';
            position: absolute;
            top: 1rem;
            right: 1.5rem;
            font-size: 0.7rem;
            font-weight: 800;
            letter-spacing: 2px;
            color: rgba(0, 176, 255, 0.4);
            border: 1px solid rgba(0, 176, 255, 0.3);
            padding: 0.2rem 0.6rem;
            border-radius: 5px;
        }}

        .ai-title {{
            font-family: 'Space Grotesk', sans-serif;
            font-size: 1.2rem;
            color: var(--accent-blue);
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }}

        .ai-text {{
            font-size: 1.1rem;
            color: #d1d5db;
            line-height: 1.7;
        }}

        table {{
            width: 100%;
            border-collapse: collapse;
            background: var(--bg-secondary);
            border-radius: 12px;
            overflow: hidden;
            border: 1px solid var(--border-color);
            margin-bottom: 2.5rem;
        }}

        th, td {{
            padding: 1.2rem;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }}

        th {{
            background-color: var(--bg-tertiary);
            font-weight: 600;
            color: var(--text-main);
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 1px;
        }}

        tr:last-child td {{
            border-bottom: none;
        }}

        .rule-code {{
            font-family: monospace;
            background: #1c2130;
            padding: 0.3rem 0.6rem;
            border-radius: 6px;
            color: #e5c07b;
            font-size: 0.9rem;
        }}

        .rule-count {{
            font-weight: 700;
            color: var(--accent-red);
            font-size: 1.05rem;
        }}

        .rule-rec {{
            color: #c8ccd4;
            font-size: 0.95rem;
        }}

        .badge {{
            padding: 0.3rem 0.6rem;
            border-radius: 6px;
            font-weight: 600;
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }}

        .badge.transaction {{
            background: rgba(0, 176, 255, 0.15);
            color: var(--accent-blue);
            border: 1px solid var(--accent-blue);
        }}

        .badge.position {{
            background: rgba(156, 39, 176, 0.15);
            color: #d500f9;
            border: 1px solid #d500f9;
        }}

        .no-failures {{
            text-align: center;
            color: var(--accent-green);
            padding: 2.5rem;
            font-weight: 600;
            font-size: 1.1rem;
        }}
    </style>
</head>
<body>

    <header>
        <div class="brand">
            <h1>WealthBridge Financial Data Platform</h1>
            <p>Ingestion Execution Report • Run ID: {run_id}</p>
        </div>
        <div class="status-pill {status.lower()}">
            {status}
        </div>
    </header>

    <div class="metrics-grid">
        <div class="card">
            <div class="card-title">Data Quality Score</div>
            <div class="card-value green">{dq_score:.2f}%</div>
        </div>
        <div class="card">
            <div class="card-title">Total Records</div>
            <div class="card-value blue">{total}</div>
        </div>
        <div class="card">
            <div class="card-title">Good Records</div>
            <div class="card-value green">{good}</div>
        </div>
        <div class="card">
            <div class="card-title">Bad Records</div>
            <div class="card-value red">{bad}</div>
        </div>
        <div class="card">
            <div class="card-title">Duration</div>
            <div class="card-value">{duration:.2f}s</div>
        </div>
    </div>

    <div class="ai-box">
        <div class="ai-title">🤖 Intelligent Data Health Analysis</div>
        <p class="ai-text">{ai_narrative}</p>
    </div>

    <div class="dashboard-layout">
        <div>
            <h2 class="section-title">🚨 Data Correction Assistant (Failed Records Guide)</h2>
            <table>
                <thead>
                    <tr>
                        <th style="width: 15%">Record ID</th>
                        <th style="width: 15%">Entity</th>
                        <th style="width: 30%">Failed Rule Code(s)</th>
                        <th style="width: 40%">Actionable Correction Guideline</th>
                    </tr>
                </thead>
                <tbody>
                    {bad_records_html}
                </tbody>
            </table>
        </div>

        <div>
            <h2 class="section-title">📊 Rule Failure Frequency</h2>
            <table>
                <thead>
                    <tr>
                        <th>Rule Code</th>
                        <th>Failures</th>
                        <th>System Help Context</th>
                    </tr>
                </thead>
                <tbody>
                    {rules_rows_html}
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>
"""

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html_content)

    print(f"\n[REPORT_GENERATED] Premium interactive dashboard HTML report successfully generated at: {Path(output_path).resolve()}")
