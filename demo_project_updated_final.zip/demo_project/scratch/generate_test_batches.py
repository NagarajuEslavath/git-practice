"""Generates test data for 3 different batches (batch1_1001, batch2_1002, batch3_1003) to test the pipeline."""
from __future__ import annotations

import csv
from pathlib import Path

TXN_COLS = [
    "transaction_id", "account_id", "transaction_type", "trade_date",
    "settlement_date", "quantity", "price", "amount", "currency"
]
POS_COLS = [
    "position_id", "account_id", "position_date", "quantity_held",
    "market_value", "currency"
]


def write_csv(path: Path, header: list[str], rows: list[list[str]]):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


def generate_batches():
    out_dir = Path(__file__).resolve().parent.parent / "sample_data"
    out_dir.mkdir(parents=True, exist_ok=True)

    # -------------------------------------------------------------------------
    # Batch 1 (File ID: 1001)
    # -------------------------------------------------------------------------
    batch1_txn = [
        ["TXN1001", "CV1001", "BUY", "2026-01-05", "2026-01-07", "100", "25.50", "2550.00", "USD"],
        ["TXN1002", "CV1001", "SELL", "2026-01-06", "2026-01-08", "50", "42.10", "2105.00", "USD"],
        ["TXN1003", "ZZ9999", "BUY", "2026-01-05", "2026-01-07", "100", "25.00", "2500.00", "USD"],  # Bad: prefix
    ]
    batch1_pos = [
        ["POS1001", "CV1001", "2026-01-15", "100", "12500.00", "USD"],
        ["POS1002", "CV1001", "2026-01-15", "50", "3200.00", "USD"],
        ["", "CV7007", "2026-01-15", "10", "500.00", "USD"],  # Bad: missing ID
    ]

    # -------------------------------------------------------------------------
    # Batch 2 (File ID: 1002)
    # -------------------------------------------------------------------------
    batch2_txn = [
        ["TXN2001", "CV2002", "DIVIDEND", "2026-01-06", "2026-01-06", "10", "1.00", "10.00", "EUR"],
        ["TXN2002", "CV2002", "TRANSFER", "2026-01-07", "2026-01-09", "200", "10.00", "2000.00", "INR"],
        ["TXN2003", "CV2002", "BUY", "2026-01-10", "2026-01-08", "30", "100.00", "3000.00", "USD"],  # Bad: date order
    ]
    batch2_pos = [
        ["POS2001", "CV2002", "2026-01-15", "0", "0.00", "EUR"],
        ["POS2002", "CV2002", "2026-01-15", "200", "45000.00", "INR"],
        ["POS2003", "CV2002", "2026-01-15", "-5", "500.00", "USD"],  # Bad: negative quantity
    ]

    # -------------------------------------------------------------------------
    # Batch 3 (File ID: 1003)
    # -------------------------------------------------------------------------
    batch3_txn = [
        ["TXN3001", "CV3003", "BUY", "2026-01-08", "2026-01-10", "75", "88.20", "6615.00", "GBP"],
        ["TXN3002", "CV3003", "SELL", "2026-01-09", "2026-01-12", "120", "15.75", "1890.00", "JPY"],
        ["TXN3003", "CV3003", "BUY", "2026-01-08", "2026-01-10", "75", "88.20", "6615.00", "XYZ"],  # Bad: currency
    ]
    batch3_pos = [
        ["POS3001", "CV3003", "2026-01-15", "75", "8800.00", "GBP"],
        ["POS3002", "CV3003", "2026-01-15", "120", "1500.00", "JPY"],
        ["POS3003", "CV3003", "2099-12-31", "10", "500.00", "USD"],  # Bad: future date
    ]

    # Write files to disk
    write_csv(out_dir / "batch1_1001_transcation.csv", TXN_COLS, batch1_txn)
    write_csv(out_dir / "batch1_1001_position.csv", POS_COLS, batch1_pos)

    write_csv(out_dir / "batch2_1002_transcation.csv", TXN_COLS, batch2_txn)
    write_csv(out_dir / "batch2_1002_position.csv", POS_COLS, batch2_pos)

    write_csv(out_dir / "batch3_1003_transcation.csv", TXN_COLS, batch3_txn)
    write_csv(out_dir / "batch3_1003_position.csv", POS_COLS, batch3_pos)

    print("\n[SUCCESS] Generated test data in 3 different batches:")
    print("  - Batch 1: batch1_1001_transcation.csv, batch1_1001_position.csv")
    print("  - Batch 2: batch2_1002_transcation.csv, batch2_1002_position.csv")
    print("  - Batch 3: batch3_1003_transcation.csv, batch3_1003_position.csv")


if __name__ == "__main__":
    generate_batches()
