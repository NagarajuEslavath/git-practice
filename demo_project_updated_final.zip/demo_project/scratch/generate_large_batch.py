"""Generates a large test batch (batch4_1004) containing exactly 100 records (60 transactions + 40 positions)."""
from __future__ import annotations

import csv
import datetime as dt
from pathlib import Path

TXN_COLS = [
    "transaction_id", "account_id", "transaction_type", "trade_date",
    "settlement_date", "quantity", "price", "amount", "currency"
]
POS_COLS = [
    "position_id", "account_id", "position_date", "quantity_held",
    "market_value", "currency"
]


def generate_large_batch():
    out_dir = Path(__file__).resolve().parent.parent / "sample_data"
    out_dir.mkdir(parents=True, exist_ok=True)

    txn_rows = []
    # Generate 60 transactions
    for i in range(1, 61):
        txn_id = f"TXN4{i:03d}"
        acct_id = "CV4001"
        txn_type = "BUY" if i % 2 == 0 else "SELL"
        trade_date = "2026-01-10"
        settle_date = "2026-01-12"
        qty = "100"
        price = "25.00"
        amt = "2500.00"
        ccy = "USD"

        # Introduce failures selectively to test DQ engine
        if i == 5:
            # Blank transaction_id
            txn_id = ""
        elif i in (10, 11):
            # Duplicate ID
            txn_id = "TXN4_DUP"
        elif i == 15:
            # Invalid account prefix
            acct_id = "ZZ4001"
        elif i == 20:
            # Invalid transaction type
            txn_type = "SHORT"
        elif i == 25:
            # Chronological date error (trade > settlement)
            settle_date = "2026-01-09"
        elif i == 30:
            # Non-positive quantity
            qty = "-10"
        elif i == 35:
            # Non-positive price
            price = "0.00"
        elif i == 40:
            # Non-positive amount
            amt = "-500.00"
        elif i == 45:
            # Unapproved currency code
            ccy = "XYZ"
        elif i == 50:
            # Blank currency
            ccy = ""

        txn_rows.append([txn_id, acct_id, txn_type, trade_date, settle_date, qty, price, amt, ccy])

    pos_rows = []
    # Generate 40 positions
    for j in range(1, 41):
        pos_id = f"POS4{j:03d}"
        acct_id = "CV4001"
        pos_date = "2026-01-15"
        qty_held = "250"
        mkt_val = "6250.00"
        ccy = "USD"

        # Introduce failures selectively to test DQ engine
        if j == 5:
            # Blank position_id
            pos_id = ""
        elif j in (10, 11):
            # Duplicate ID
            pos_id = "POS4_DUP"
        elif j == 15:
            # Invalid account prefix
            acct_id = "ZZ4001"
        elif j == 20:
            # Future position date
            pos_date = "2099-12-31"
        elif j == 25:
            # Negative quantity held
            qty_held = "-5"
        elif j == 30:
            # Negative market value
            mkt_val = "-100.00"
        elif j == 35:
            # Unapproved currency
            ccy = "ABC"

        pos_rows.append([pos_id, acct_id, pos_date, qty_held, mkt_val, ccy])

    # Write files to disk
    write_path_txn = out_dir / "batch4_1004_transcation.csv"
    write_path_pos = out_dir / "batch4_1004_position.csv"

    with open(write_path_txn, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(TXN_COLS)
        w.writerows(txn_rows)

    with open(write_path_pos, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(POS_COLS)
        w.writerows(pos_rows)

    print("\n[SUCCESS] Generated Large Test Batch 4 (File ID: 1004):")
    print(f"  - Transactions : {len(txn_rows)} records written to {write_path_txn.name}")
    print(f"  - Positions    : {len(pos_rows)} records written to {write_path_pos.name}")
    print(f"  - Total Batch  : {len(txn_rows) + len(pos_rows)} records")


if __name__ == "__main__":
    generate_large_batch()
